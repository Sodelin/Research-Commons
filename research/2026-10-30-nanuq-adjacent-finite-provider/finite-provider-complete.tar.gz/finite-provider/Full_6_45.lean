import Nodes_6_45
import Props_6_45
set_option debug.skipKernelTC false
namespace Nanuq.AdjacentCertificate.Certificate_6_45
theorem every_tree_full (t : Tree) (hs : t.size = 9) : checkPattern 6 qs (t.summary (edgeContribution tips qs) 1) = true := by
 apply List.all_eq_true.mp top_checked
 have hh := summary_mem _ 10 cert actual_closed t 1 (by omega)
 simpa only [hs] using hh
#print axioms every_tree_full
end Nanuq.AdjacentCertificate.Certificate_6_45
