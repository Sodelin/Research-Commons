import SplitCertificate
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_4_5
def tips : List Nat := [0, 0, 1, 2, 2, 3]
def qs : List Quartet := [⟨0,1,2,3⟩]
def data : List (List Nat) := [[], [0], [0], [1], [1, 5], [1, 4, 5], [1, 4, 5], [], [0], [1], [5], [4, 5], [1, 4, 5], [], [], [0], [4], [4], [1, 4, 5], [], [], [], [0], [0], [1], [], [], [], [], [0], [1], [], [], [], [], [], [0], [], [], [], [], []]
def cert : Table := tableFrom 6 data
 theorem tips_exact : tips = occurrenceLabels 4 5 := by decide +kernel
 theorem qs_exact : qs = quartets 4 := by decide +kernel

end Nanuq.AdjacentCertificate.Certificate_4_5
