import Data_6_22
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_22
theorem node_7_0 : checkNode (edgeContribution tips qs) 9 cert 7 0 = true := by rfl
theorem node_7_1 : checkNode (edgeContribution tips qs) 9 cert 7 1 = true := by rfl
theorem node_7_2 : checkNode (edgeContribution tips qs) 9 cert 7 2 = true := by decide +kernel
theorem node_7_3 : checkNode (edgeContribution tips qs) 9 cert 7 3 = true := by rfl
theorem node_7_4 : checkNode (edgeContribution tips qs) 9 cert 7 4 = true := by rfl
theorem node_7_5 : checkNode (edgeContribution tips qs) 9 cert 7 5 = true := by rfl
theorem node_7_6 : checkNode (edgeContribution tips qs) 9 cert 7 6 = true := by rfl
theorem node_7_7 : checkNode (edgeContribution tips qs) 9 cert 7 7 = true := by rfl
theorem node_7_8 : checkNode (edgeContribution tips qs) 9 cert 7 8 = true := by rfl
theorem node_7_9 : checkNode (edgeContribution tips qs) 9 cert 7 9 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_22
