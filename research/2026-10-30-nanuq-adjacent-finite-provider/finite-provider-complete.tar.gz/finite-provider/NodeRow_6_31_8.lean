import Data_6_31
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_31
theorem node_8_0 : checkNode (edgeContribution tips qs) 11 cert 8 0 = true := by rfl
theorem node_8_1 : checkNode (edgeContribution tips qs) 11 cert 8 1 = true := by rfl
theorem node_8_2 : checkNode (edgeContribution tips qs) 11 cert 8 2 = true := by decide +kernel
theorem node_8_3 : checkNode (edgeContribution tips qs) 11 cert 8 3 = true := by decide +kernel
theorem node_8_4 : checkNode (edgeContribution tips qs) 11 cert 8 4 = true := by rfl
theorem node_8_5 : checkNode (edgeContribution tips qs) 11 cert 8 5 = true := by rfl
theorem node_8_6 : checkNode (edgeContribution tips qs) 11 cert 8 6 = true := by rfl
theorem node_8_7 : checkNode (edgeContribution tips qs) 11 cert 8 7 = true := by rfl
theorem node_8_8 : checkNode (edgeContribution tips qs) 11 cert 8 8 = true := by rfl
theorem node_8_9 : checkNode (edgeContribution tips qs) 11 cert 8 9 = true := by rfl
theorem node_8_10 : checkNode (edgeContribution tips qs) 11 cert 8 10 = true := by rfl
theorem node_8_11 : checkNode (edgeContribution tips qs) 11 cert 8 11 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_31
