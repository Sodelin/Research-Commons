import Nodes_3_6
import Props_3_6
set_option debug.skipKernelTC false
namespace Nanuq.AdjacentCertificate.Certificate_3_6
theorem every_tree_full (t : Tree) (hs : t.size = 4) : checkPattern 3 qs (t.summary (edgeContribution tips qs) 1) = true := by
 apply List.all_eq_true.mp top_checked
 have hh := summary_mem _ 5 cert actual_closed t 1 (by omega)
 simpa only [hs] using hh
#print axioms every_tree_full
end Nanuq.AdjacentCertificate.Certificate_3_6
