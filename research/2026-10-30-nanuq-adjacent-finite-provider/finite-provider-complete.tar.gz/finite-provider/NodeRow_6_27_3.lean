import Data_6_27
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_27
theorem node_3_0 : checkNode (edgeContribution tips qs) 10 cert 3 0 = true := by rfl
theorem node_3_1 : checkNode (edgeContribution tips qs) 10 cert 3 1 = true := by rfl
theorem node_3_2 : checkNode (edgeContribution tips qs) 10 cert 3 2 = true := by decide +kernel
theorem node_3_3 : checkNode (edgeContribution tips qs) 10 cert 3 3 = true := by decide +kernel
theorem node_3_4 : checkNode (edgeContribution tips qs) 10 cert 3 4 = true := by decide +kernel
theorem node_3_5 : checkNode (edgeContribution tips qs) 10 cert 3 5 = true := by decide +kernel
theorem node_3_6 : checkNode (edgeContribution tips qs) 10 cert 3 6 = true := by decide +kernel
theorem node_3_7 : checkNode (edgeContribution tips qs) 10 cert 3 7 = true := by decide +kernel
theorem node_3_8 : checkNode (edgeContribution tips qs) 10 cert 3 8 = true := by rfl
theorem node_3_9 : checkNode (edgeContribution tips qs) 10 cert 3 9 = true := by rfl
theorem node_3_10 : checkNode (edgeContribution tips qs) 10 cert 3 10 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_27
