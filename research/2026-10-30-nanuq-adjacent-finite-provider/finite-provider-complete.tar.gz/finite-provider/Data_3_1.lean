import SplitCertificate
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_3_1
def tips : List Nat := [0, 0, 1, 2]
def qs : List Quartet := []
def data : List (List Nat) := [[], [0], [0], [0], [0], [], [0], [0], [0], [], [], [0], [0], [], [], [], [0], [], [], []]
def cert : Table := tableFrom 4 data
 theorem tips_exact : tips = occurrenceLabels 3 1 := by decide +kernel
 theorem qs_exact : qs = quartets 3 := by decide +kernel

end Nanuq.AdjacentCertificate.Certificate_3_1
