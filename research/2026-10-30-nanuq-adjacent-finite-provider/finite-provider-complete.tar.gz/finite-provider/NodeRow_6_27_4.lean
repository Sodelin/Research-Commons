import Data_6_27
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_27
theorem node_4_0 : checkNode (edgeContribution tips qs) 10 cert 4 0 = true := by rfl
theorem node_4_1 : checkNode (edgeContribution tips qs) 10 cert 4 1 = true := by rfl
theorem node_4_2 : checkNode (edgeContribution tips qs) 10 cert 4 2 = true := by decide +kernel
theorem node_4_3 : checkNode (edgeContribution tips qs) 10 cert 4 3 = true := by decide +kernel
theorem node_4_4 : checkNode (edgeContribution tips qs) 10 cert 4 4 = true := by decide +kernel
theorem node_4_5 : checkNode (edgeContribution tips qs) 10 cert 4 5 = true := by decide +kernel
theorem node_4_6 : checkNode (edgeContribution tips qs) 10 cert 4 6 = true := by decide +kernel
theorem node_4_7 : checkNode (edgeContribution tips qs) 10 cert 4 7 = true := by rfl
theorem node_4_8 : checkNode (edgeContribution tips qs) 10 cert 4 8 = true := by rfl
theorem node_4_9 : checkNode (edgeContribution tips qs) 10 cert 4 9 = true := by rfl
theorem node_4_10 : checkNode (edgeContribution tips qs) 10 cert 4 10 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_27
