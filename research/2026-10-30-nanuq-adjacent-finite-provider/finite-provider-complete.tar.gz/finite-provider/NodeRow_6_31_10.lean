import Data_6_31
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_31
theorem node_10_0 : checkNode (edgeContribution tips qs) 11 cert 10 0 = true := by rfl
theorem node_10_1 : checkNode (edgeContribution tips qs) 11 cert 10 1 = true := by rfl
theorem node_10_2 : checkNode (edgeContribution tips qs) 11 cert 10 2 = true := by rfl
theorem node_10_3 : checkNode (edgeContribution tips qs) 11 cert 10 3 = true := by rfl
theorem node_10_4 : checkNode (edgeContribution tips qs) 11 cert 10 4 = true := by rfl
theorem node_10_5 : checkNode (edgeContribution tips qs) 11 cert 10 5 = true := by rfl
theorem node_10_6 : checkNode (edgeContribution tips qs) 11 cert 10 6 = true := by rfl
theorem node_10_7 : checkNode (edgeContribution tips qs) 11 cert 10 7 = true := by rfl
theorem node_10_8 : checkNode (edgeContribution tips qs) 11 cert 10 8 = true := by rfl
theorem node_10_9 : checkNode (edgeContribution tips qs) 11 cert 10 9 = true := by rfl
theorem node_10_10 : checkNode (edgeContribution tips qs) 11 cert 10 10 = true := by rfl
theorem node_10_11 : checkNode (edgeContribution tips qs) 11 cert 10 11 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_31
