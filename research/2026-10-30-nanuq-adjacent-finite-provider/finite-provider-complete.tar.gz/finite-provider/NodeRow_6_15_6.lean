import Data_6_15
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_15
theorem node_6_0 : checkNode (edgeContribution tips qs) 10 cert 6 0 = true := by rfl
theorem node_6_1 : checkNode (edgeContribution tips qs) 10 cert 6 1 = true := by rfl
theorem node_6_2 : checkNode (edgeContribution tips qs) 10 cert 6 2 = true := by decide +kernel
theorem node_6_3 : checkNode (edgeContribution tips qs) 10 cert 6 3 = true := by decide +kernel
theorem node_6_4 : checkNode (edgeContribution tips qs) 10 cert 6 4 = true := by decide +kernel
theorem node_6_5 : checkNode (edgeContribution tips qs) 10 cert 6 5 = true := by rfl
theorem node_6_6 : checkNode (edgeContribution tips qs) 10 cert 6 6 = true := by rfl
theorem node_6_7 : checkNode (edgeContribution tips qs) 10 cert 6 7 = true := by rfl
theorem node_6_8 : checkNode (edgeContribution tips qs) 10 cert 6 8 = true := by rfl
theorem node_6_9 : checkNode (edgeContribution tips qs) 10 cert 6 9 = true := by rfl
theorem node_6_10 : checkNode (edgeContribution tips qs) 10 cert 6 10 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_15
