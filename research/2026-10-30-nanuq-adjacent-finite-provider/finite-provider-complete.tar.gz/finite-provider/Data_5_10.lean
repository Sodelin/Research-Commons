import SplitCertificate
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_5_10
def tips : List Nat := [0, 1, 1, 2, 3, 3, 4]
def qs : List Quartet := [⟨0,1,2,3⟩,⟨0,1,2,4⟩,⟨0,1,3,4⟩,⟨0,2,3,4⟩,⟨1,2,3,4⟩]
def data : List (List Nat) := [[], [0], [73], [73], [4681, 4708, 4717], [4681, 4708, 4717, 7012, 23113, 23397, 23405], [4681, 4708, 4717, 6436, 7012, 18505, 18721, 18793, 22821, 22893, 23113, 23397, 23405], [4681, 4708, 4717, 6436, 7012, 18505, 18721, 18793, 22821, 22893, 23113, 23397, 23405], [], [0], [0], [4132], [6436, 22821], [6436, 18721, 22821], [4681, 4708, 4717, 6436, 7012, 18505, 18721, 18793, 22821, 22893, 23113, 23397, 23405], [], [], [0], [4132], [22821], [18721, 22821], [4681, 4717, 18505, 18793, 22893, 23113, 23405], [], [], [], [0], [18433], [18433], [4681, 18505, 23113], [], [], [], [], [0], [0], [4672], [], [], [], [], [], [0], [4672], [], [], [], [], [], [], [0], [], [], [], [], [], []]
def cert : Table := tableFrom 7 data
 theorem tips_exact : tips = occurrenceLabels 5 10 := by decide +kernel
 theorem qs_exact : qs = quartets 5 := by decide +kernel

end Nanuq.AdjacentCertificate.Certificate_5_10
