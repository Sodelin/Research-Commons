import Nodes_6_10
import Props_6_10
set_option debug.skipKernelTC false
namespace Nanuq.AdjacentCertificate.Certificate_6_10
theorem every_tree_full (t : Tree) (hs : t.size = 7) : checkPattern 6 qs (t.summary (edgeContribution tips qs) 1) = true := by
 apply List.all_eq_true.mp top_checked
 have hh := summary_mem _ 8 cert actual_closed t 1 (by omega)
 simpa only [hs] using hh
#print axioms every_tree_full
end Nanuq.AdjacentCertificate.Certificate_6_10
