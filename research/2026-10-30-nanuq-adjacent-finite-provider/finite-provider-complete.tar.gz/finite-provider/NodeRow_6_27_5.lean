import Data_6_27
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_27
theorem node_5_0 : checkNode (edgeContribution tips qs) 10 cert 5 0 = true := by rfl
theorem node_5_1 : checkNode (edgeContribution tips qs) 10 cert 5 1 = true := by rfl
theorem node_5_2 : checkNode (edgeContribution tips qs) 10 cert 5 2 = true := by decide +kernel
theorem node_5_3 : checkNode (edgeContribution tips qs) 10 cert 5 3 = true := by decide +kernel
theorem node_5_4 : checkNode (edgeContribution tips qs) 10 cert 5 4 = true := by decide +kernel
theorem node_5_5 : checkNode (edgeContribution tips qs) 10 cert 5 5 = true := by decide +kernel
theorem node_5_6 : checkNode (edgeContribution tips qs) 10 cert 5 6 = true := by rfl
theorem node_5_7 : checkNode (edgeContribution tips qs) 10 cert 5 7 = true := by rfl
theorem node_5_8 : checkNode (edgeContribution tips qs) 10 cert 5 8 = true := by rfl
theorem node_5_9 : checkNode (edgeContribution tips qs) 10 cert 5 9 = true := by rfl
theorem node_5_10 : checkNode (edgeContribution tips qs) 10 cert 5 10 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_27
