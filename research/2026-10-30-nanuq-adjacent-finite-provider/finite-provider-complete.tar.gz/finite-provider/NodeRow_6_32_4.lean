import Data_6_32
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_32
theorem node_4_0 : checkNode (edgeContribution tips qs) 7 cert 4 0 = true := by rfl
theorem node_4_1 : checkNode (edgeContribution tips qs) 7 cert 4 1 = true := by rfl
theorem node_4_2 : checkNode (edgeContribution tips qs) 7 cert 4 2 = true := by decide +kernel
theorem node_4_3 : checkNode (edgeContribution tips qs) 7 cert 4 3 = true := by decide +kernel
theorem node_4_4 : checkNode (edgeContribution tips qs) 7 cert 4 4 = true := by rfl
theorem node_4_5 : checkNode (edgeContribution tips qs) 7 cert 4 5 = true := by rfl
theorem node_4_6 : checkNode (edgeContribution tips qs) 7 cert 4 6 = true := by rfl
theorem node_4_7 : checkNode (edgeContribution tips qs) 7 cert 4 7 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_32
