import Data_6_14
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_14
theorem node_1_0 : checkNode (edgeContribution tips qs) 9 cert 1 0 = true := by rfl
theorem node_1_1 : checkNode (edgeContribution tips qs) 9 cert 1 1 = true := by rfl
theorem node_1_2 : checkNode (edgeContribution tips qs) 9 cert 1 2 = true := by decide +kernel
theorem node_1_3 : checkNode (edgeContribution tips qs) 9 cert 1 3 = true := by decide +kernel
theorem node_1_4 : checkNode (edgeContribution tips qs) 9 cert 1 4 = true := by decide +kernel
theorem node_1_5 : checkNode (edgeContribution tips qs) 9 cert 1 5 = true := by decide +kernel
theorem node_1_6 : checkNode (edgeContribution tips qs) 9 cert 1 6 = true := by decide +kernel
theorem node_1_7 : checkNode (edgeContribution tips qs) 9 cert 1 7 = true := by decide +kernel
theorem node_1_8 : checkNode (edgeContribution tips qs) 9 cert 1 8 = true := by decide +kernel
theorem node_1_9 : checkNode (edgeContribution tips qs) 9 cert 1 9 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_14
