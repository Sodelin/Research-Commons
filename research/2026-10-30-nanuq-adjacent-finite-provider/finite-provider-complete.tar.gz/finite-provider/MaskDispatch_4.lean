import Full_4_0
import Full_4_1
import Full_4_2
import Full_4_3
import Full_4_4
import Full_4_5
import Full_4_6
import Full_4_7
import Full_4_8
import Full_4_9
import Full_4_10
import Full_4_11
import Full_4_12
import Full_4_13
import Full_4_14
import Full_4_15
import Mathlib.Tactic.IntervalCases
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate
theorem all_masks_4 (mask : Nat) (hm : mask < 16)
    (t : Tree) (hs : t.size = (occurrenceLabels 4 mask).length - 1) :
    checkPattern 4 (quartets 4) (t.summary (edgeContribution (occurrenceLabels 4 mask) (quartets 4)) 1) = true := by
  interval_cases mask
  · exact Certificate_4_0.every_tree_full t hs
  · exact Certificate_4_1.every_tree_full t hs
  · exact Certificate_4_2.every_tree_full t hs
  · exact Certificate_4_3.every_tree_full t hs
  · exact Certificate_4_4.every_tree_full t hs
  · exact Certificate_4_5.every_tree_full t hs
  · exact Certificate_4_6.every_tree_full t hs
  · exact Certificate_4_7.every_tree_full t hs
  · exact Certificate_4_8.every_tree_full t hs
  · exact Certificate_4_9.every_tree_full t hs
  · exact Certificate_4_10.every_tree_full t hs
  · exact Certificate_4_11.every_tree_full t hs
  · exact Certificate_4_12.every_tree_full t hs
  · exact Certificate_4_13.every_tree_full t hs
  · exact Certificate_4_14.every_tree_full t hs
  · exact Certificate_4_15.every_tree_full t hs
#print axioms all_masks_4
end Nanuq.AdjacentCertificate
