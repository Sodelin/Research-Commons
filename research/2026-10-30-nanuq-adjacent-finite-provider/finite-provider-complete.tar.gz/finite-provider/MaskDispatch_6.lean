import Full_6_0
import Full_6_1
import Full_6_2
import Full_6_3
import Full_6_4
import Full_6_5
import Full_6_6
import Full_6_7
import Full_6_8
import Full_6_9
import Full_6_10
import Full_6_11
import Full_6_12
import Full_6_13
import Full_6_14
import Full_6_15
import Full_6_16
import Full_6_17
import Full_6_18
import Full_6_19
import Full_6_20
import Full_6_21
import Full_6_22
import Full_6_23
import Full_6_24
import Full_6_25
import Full_6_26
import Full_6_27
import Full_6_28
import Full_6_29
import Full_6_30
import Full_6_31
import Full_6_32
import Full_6_33
import Full_6_34
import Full_6_35
import Full_6_36
import Full_6_37
import Full_6_38
import Full_6_39
import Full_6_40
import Full_6_41
import Full_6_42
import Full_6_43
import Full_6_44
import Full_6_45
import Full_6_46
import Full_6_47
import Full_6_48
import Full_6_49
import Full_6_50
import Full_6_51
import Full_6_52
import Full_6_53
import Full_6_54
import Full_6_55
import Full_6_56
import Full_6_57
import Full_6_58
import Full_6_59
import Full_6_60
import Full_6_61
import Full_6_62
import Full_6_63
import Mathlib.Tactic.IntervalCases
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate
theorem all_masks_6 (mask : Nat) (hm : mask < 64)
    (t : Tree) (hs : t.size = (occurrenceLabels 6 mask).length - 1) :
    checkPattern 6 (quartets 6) (t.summary (edgeContribution (occurrenceLabels 6 mask) (quartets 6)) 1) = true := by
  interval_cases mask
  · exact Certificate_6_0.every_tree_full t hs
  · exact Certificate_6_1.every_tree_full t hs
  · exact Certificate_6_2.every_tree_full t hs
  · exact Certificate_6_3.every_tree_full t hs
  · exact Certificate_6_4.every_tree_full t hs
  · exact Certificate_6_5.every_tree_full t hs
  · exact Certificate_6_6.every_tree_full t hs
  · exact Certificate_6_7.every_tree_full t hs
  · exact Certificate_6_8.every_tree_full t hs
  · exact Certificate_6_9.every_tree_full t hs
  · exact Certificate_6_10.every_tree_full t hs
  · exact Certificate_6_11.every_tree_full t hs
  · exact Certificate_6_12.every_tree_full t hs
  · exact Certificate_6_13.every_tree_full t hs
  · exact Certificate_6_14.every_tree_full t hs
  · exact Certificate_6_15.every_tree_full t hs
  · exact Certificate_6_16.every_tree_full t hs
  · exact Certificate_6_17.every_tree_full t hs
  · exact Certificate_6_18.every_tree_full t hs
  · exact Certificate_6_19.every_tree_full t hs
  · exact Certificate_6_20.every_tree_full t hs
  · exact Certificate_6_21.every_tree_full t hs
  · exact Certificate_6_22.every_tree_full t hs
  · exact Certificate_6_23.every_tree_full t hs
  · exact Certificate_6_24.every_tree_full t hs
  · exact Certificate_6_25.every_tree_full t hs
  · exact Certificate_6_26.every_tree_full t hs
  · exact Certificate_6_27.every_tree_full t hs
  · exact Certificate_6_28.every_tree_full t hs
  · exact Certificate_6_29.every_tree_full t hs
  · exact Certificate_6_30.every_tree_full t hs
  · exact Certificate_6_31.every_tree_full t hs
  · exact Certificate_6_32.every_tree_full t hs
  · exact Certificate_6_33.every_tree_full t hs
  · exact Certificate_6_34.every_tree_full t hs
  · exact Certificate_6_35.every_tree_full t hs
  · exact Certificate_6_36.every_tree_full t hs
  · exact Certificate_6_37.every_tree_full t hs
  · exact Certificate_6_38.every_tree_full t hs
  · exact Certificate_6_39.every_tree_full t hs
  · exact Certificate_6_40.every_tree_full t hs
  · exact Certificate_6_41.every_tree_full t hs
  · exact Certificate_6_42.every_tree_full t hs
  · exact Certificate_6_43.every_tree_full t hs
  · exact Certificate_6_44.every_tree_full t hs
  · exact Certificate_6_45.every_tree_full t hs
  · exact Certificate_6_46.every_tree_full t hs
  · exact Certificate_6_47.every_tree_full t hs
  · exact Certificate_6_48.every_tree_full t hs
  · exact Certificate_6_49.every_tree_full t hs
  · exact Certificate_6_50.every_tree_full t hs
  · exact Certificate_6_51.every_tree_full t hs
  · exact Certificate_6_52.every_tree_full t hs
  · exact Certificate_6_53.every_tree_full t hs
  · exact Certificate_6_54.every_tree_full t hs
  · exact Certificate_6_55.every_tree_full t hs
  · exact Certificate_6_56.every_tree_full t hs
  · exact Certificate_6_57.every_tree_full t hs
  · exact Certificate_6_58.every_tree_full t hs
  · exact Certificate_6_59.every_tree_full t hs
  · exact Certificate_6_60.every_tree_full t hs
  · exact Certificate_6_61.every_tree_full t hs
  · exact Certificate_6_62.every_tree_full t hs
  · exact Certificate_6_63.every_tree_full t hs
#print axioms all_masks_6
end Nanuq.AdjacentCertificate
