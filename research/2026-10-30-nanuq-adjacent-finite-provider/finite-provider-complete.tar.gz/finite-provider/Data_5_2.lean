import SplitCertificate
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_5_2
def tips : List Nat := [0, 1, 1, 2, 3, 4]
def qs : List Quartet := [⟨0,1,2,3⟩,⟨0,1,2,4⟩,⟨0,1,3,4⟩,⟨0,2,3,4⟩,⟨1,2,3,4⟩]
def data : List (List Nat) := [[], [0], [73], [73], [4681, 4708, 4717], [4681, 4708, 4717, 6436, 18505, 18721, 18793, 22821, 22893], [4681, 4708, 4717, 6436, 18505, 18721, 18793, 22821, 22893], [], [0], [0], [4132], [6436, 18721, 22821], [4681, 4708, 4717, 6436, 18505, 18721, 18793, 22821, 22893], [], [], [0], [4132], [18721, 22821], [4681, 4717, 18505, 18793, 22893], [], [], [], [0], [18433], [4681, 18505], [], [], [], [], [0], [4672], [], [], [], [], [], [0], [], [], [], [], []]
def cert : Table := tableFrom 6 data
 theorem tips_exact : tips = occurrenceLabels 5 2 := by decide +kernel
 theorem qs_exact : qs = quartets 5 := by decide +kernel

end Nanuq.AdjacentCertificate.Certificate_5_2
