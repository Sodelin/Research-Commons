import Data_6_32
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_32
theorem node_2_0 : checkNode (edgeContribution tips qs) 7 cert 2 0 = true := by rfl
theorem node_2_1 : checkNode (edgeContribution tips qs) 7 cert 2 1 = true := by rfl
theorem node_2_2 : checkNode (edgeContribution tips qs) 7 cert 2 2 = true := by decide +kernel
theorem node_2_3 : checkNode (edgeContribution tips qs) 7 cert 2 3 = true := by decide +kernel
theorem node_2_4 : checkNode (edgeContribution tips qs) 7 cert 2 4 = true := by decide +kernel
theorem node_2_5 : checkNode (edgeContribution tips qs) 7 cert 2 5 = true := by decide +kernel
theorem node_2_6 : checkNode (edgeContribution tips qs) 7 cert 2 6 = true := by rfl
theorem node_2_7 : checkNode (edgeContribution tips qs) 7 cert 2 7 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_32
