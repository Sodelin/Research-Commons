import Data_6_28
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_28
theorem node_0_0 : checkNode (edgeContribution tips qs) 9 cert 0 0 = true := by rfl
theorem node_0_1 : checkNode (edgeContribution tips qs) 9 cert 0 1 = true := by rfl
theorem node_0_2 : checkNode (edgeContribution tips qs) 9 cert 0 2 = true := by decide +kernel
theorem node_0_3 : checkNode (edgeContribution tips qs) 9 cert 0 3 = true := by decide +kernel
theorem node_0_4 : checkNode (edgeContribution tips qs) 9 cert 0 4 = true := by decide +kernel
theorem node_0_5 : checkNode (edgeContribution tips qs) 9 cert 0 5 = true := by decide +kernel
theorem node_0_6 : checkNode (edgeContribution tips qs) 9 cert 0 6 = true := by decide +kernel
theorem node_0_7 : checkNode (edgeContribution tips qs) 9 cert 0 7 = true := by decide +kernel
theorem node_0_8 : checkNode (edgeContribution tips qs) 9 cert 0 8 = true := by decide +kernel
theorem node_0_9 : checkNode (edgeContribution tips qs) 9 cert 0 9 = true := by decide +kernel
end Nanuq.AdjacentCertificate.Certificate_6_28
