import Nodes_4_5
import Props_4_5
set_option debug.skipKernelTC false
namespace Nanuq.AdjacentCertificate.Certificate_4_5
theorem every_tree_full (t : Tree) (hs : t.size = 5) : checkPattern 4 qs (t.summary (edgeContribution tips qs) 1) = true := by
 apply List.all_eq_true.mp top_checked
 have hh := summary_mem _ 6 cert actual_closed t 1 (by omega)
 simpa only [hs] using hh
#print axioms every_tree_full
end Nanuq.AdjacentCertificate.Certificate_4_5
