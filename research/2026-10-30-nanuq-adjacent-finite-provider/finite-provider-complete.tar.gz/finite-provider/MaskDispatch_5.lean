import Full_5_0
import Full_5_1
import Full_5_2
import Full_5_3
import Full_5_4
import Full_5_5
import Full_5_6
import Full_5_7
import Full_5_8
import Full_5_9
import Full_5_10
import Full_5_11
import Full_5_12
import Full_5_13
import Full_5_14
import Full_5_15
import Full_5_16
import Full_5_17
import Full_5_18
import Full_5_19
import Full_5_20
import Full_5_21
import Full_5_22
import Full_5_23
import Full_5_24
import Full_5_25
import Full_5_26
import Full_5_27
import Full_5_28
import Full_5_29
import Full_5_30
import Full_5_31
import Mathlib.Tactic.IntervalCases
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate
theorem all_masks_5 (mask : Nat) (hm : mask < 32)
    (t : Tree) (hs : t.size = (occurrenceLabels 5 mask).length - 1) :
    checkPattern 5 (quartets 5) (t.summary (edgeContribution (occurrenceLabels 5 mask) (quartets 5)) 1) = true := by
  interval_cases mask
  · exact Certificate_5_0.every_tree_full t hs
  · exact Certificate_5_1.every_tree_full t hs
  · exact Certificate_5_2.every_tree_full t hs
  · exact Certificate_5_3.every_tree_full t hs
  · exact Certificate_5_4.every_tree_full t hs
  · exact Certificate_5_5.every_tree_full t hs
  · exact Certificate_5_6.every_tree_full t hs
  · exact Certificate_5_7.every_tree_full t hs
  · exact Certificate_5_8.every_tree_full t hs
  · exact Certificate_5_9.every_tree_full t hs
  · exact Certificate_5_10.every_tree_full t hs
  · exact Certificate_5_11.every_tree_full t hs
  · exact Certificate_5_12.every_tree_full t hs
  · exact Certificate_5_13.every_tree_full t hs
  · exact Certificate_5_14.every_tree_full t hs
  · exact Certificate_5_15.every_tree_full t hs
  · exact Certificate_5_16.every_tree_full t hs
  · exact Certificate_5_17.every_tree_full t hs
  · exact Certificate_5_18.every_tree_full t hs
  · exact Certificate_5_19.every_tree_full t hs
  · exact Certificate_5_20.every_tree_full t hs
  · exact Certificate_5_21.every_tree_full t hs
  · exact Certificate_5_22.every_tree_full t hs
  · exact Certificate_5_23.every_tree_full t hs
  · exact Certificate_5_24.every_tree_full t hs
  · exact Certificate_5_25.every_tree_full t hs
  · exact Certificate_5_26.every_tree_full t hs
  · exact Certificate_5_27.every_tree_full t hs
  · exact Certificate_5_28.every_tree_full t hs
  · exact Certificate_5_29.every_tree_full t hs
  · exact Certificate_5_30.every_tree_full t hs
  · exact Certificate_5_31.every_tree_full t hs
#print axioms all_masks_5
end Nanuq.AdjacentCertificate
