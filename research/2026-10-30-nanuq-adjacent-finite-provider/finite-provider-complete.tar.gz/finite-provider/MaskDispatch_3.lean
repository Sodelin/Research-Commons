import Full_3_0
import Full_3_1
import Full_3_2
import Full_3_3
import Full_3_4
import Full_3_5
import Full_3_6
import Full_3_7
import Mathlib.Tactic.IntervalCases
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate
theorem all_masks_3 (mask : Nat) (hm : mask < 8)
    (t : Tree) (hs : t.size = (occurrenceLabels 3 mask).length - 1) :
    checkPattern 3 (quartets 3) (t.summary (edgeContribution (occurrenceLabels 3 mask) (quartets 3)) 1) = true := by
  interval_cases mask
  · exact Certificate_3_0.every_tree_full t hs
  · exact Certificate_3_1.every_tree_full t hs
  · exact Certificate_3_2.every_tree_full t hs
  · exact Certificate_3_3.every_tree_full t hs
  · exact Certificate_3_4.every_tree_full t hs
  · exact Certificate_3_5.every_tree_full t hs
  · exact Certificate_3_6.every_tree_full t hs
  · exact Certificate_3_7.every_tree_full t hs
#print axioms all_masks_3
end Nanuq.AdjacentCertificate
