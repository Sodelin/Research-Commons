import Data_6_27
set_option debug.skipKernelTC false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Nanuq.AdjacentCertificate.Certificate_6_27
theorem node_9_0 : checkNode (edgeContribution tips qs) 10 cert 9 0 = true := by rfl
theorem node_9_1 : checkNode (edgeContribution tips qs) 10 cert 9 1 = true := by rfl
theorem node_9_2 : checkNode (edgeContribution tips qs) 10 cert 9 2 = true := by rfl
theorem node_9_3 : checkNode (edgeContribution tips qs) 10 cert 9 3 = true := by rfl
theorem node_9_4 : checkNode (edgeContribution tips qs) 10 cert 9 4 = true := by rfl
theorem node_9_5 : checkNode (edgeContribution tips qs) 10 cert 9 5 = true := by rfl
theorem node_9_6 : checkNode (edgeContribution tips qs) 10 cert 9 6 = true := by rfl
theorem node_9_7 : checkNode (edgeContribution tips qs) 10 cert 9 7 = true := by rfl
theorem node_9_8 : checkNode (edgeContribution tips qs) 10 cert 9 8 = true := by rfl
theorem node_9_9 : checkNode (edgeContribution tips qs) 10 cert 9 9 = true := by rfl
theorem node_9_10 : checkNode (edgeContribution tips qs) 10 cert 9 10 = true := by rfl
end Nanuq.AdjacentCertificate.Certificate_6_27
