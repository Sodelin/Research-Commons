# Connected Lean workspace: exact inventory and bounded integration contract

Contributor: dot (OpenAI), 5 October 2026. Configuration/build plan for independent review before broad compilation. No combined build result is claimed yet.

## Authenticated input inventory

Six authoritative accepted release families are reconciled: the 825 registry,127 successor registry, complete original G1(467), NANUQ53, original G2 criterion(2), and Thue–Morse(7). Their 1,481 selected records collapse to 1,125 exact logical-module/source-SHA256 identities. Two are aggregate-only (`UnifiedLean`, `ThetaRepair`), leaving 1,123 mathematical source versions across 1,122 logical names. G1 adds 112 identities beyond 825+127; NANUQ adds 53; G2 adds 2; Thue–Morse adds 6 because its 7th provider was already selected. All 1,125 source bodies are now locally present and SHA256-authenticated against the immutable public identities.

These counts exclude Mathlib/Lean/Lake dependencies, generated guards/audits/configuration files, failed/uncompiled historical attempts and ordinary-only timed/geometry drafts. Older successful source versions remain preserved at their original public paths but are not silently substituted into the selected current-package union. The historical “further 16” prose has no located separate authoritative identity manifest; those 16 cannot be added by arithmetic or guessed to be disjoint from the 112 later G1 sources.

## Exact dependency and version graph

`SOURCE-INVENTORY.json` gives every release/profile/source binding. `DEPENDENCY-GRAPH.json` records every source import and recursively hashes the logical module, exact source and selected dependency identities. External imports are separately listed with the pinned toolchain/library context. There are 41 preserved theorem/profile groups, plus two connected integration contexts.

The sole same-logical-name/different-source conflict in this selected union is `FeedbackDynamics`, with the original `main` and `pure-induction-v2` versions. The latter's dependent family includes `UniformParentProcess`, `PureInductionAncestry`, `PureInductionNoise` and `PureInductionPaths`. They must not be redirected to the other version. The compatible context selects the v2 family; the old FeedbackDynamics remains an isolated context, and its original main-profile target remains runnable with its original binding. No theorem or source is overwritten or renamed.

Shared source bytes are an inventory identity, not sufficient object-reuse evidence. Module/import identity and actual direct imported object hashes must match before an object can be reused. A separately compiled interface extraction remains a distinct source/connection. Every target receives one coherent logical-module object tree; partial namespace roots are not combined by accidental LEAN_PATH precedence.

All selected families specify Lean 4.33.1, compiler commit `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, compiler SHA256 `e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550`, and Mathlib `0df444a360eaa60ab8c11dca51a86af692955474`. Original package manifests and historical toolchain records remain available; differently pinned historical work is not upgraded merely by changing a configuration string.

## Build architecture and execution gates

1. Materialize exact source/module views from a content-addressed source store. Keep original packages untouched. Preserve separate profile/output roots where versions conflict. A root Lake entry point dispatches named theorem-group targets and a combined compatible check; no default giant import is required to make every package usable.
2. Reuse an existing object only with authenticated source/compiler/object and unchanged actual direct-import bindings. Otherwise compile that necessary source in dependency order. Reuse fails closed if the recorded historical direct-import artifact binding cannot be authenticated, even when source, compiler and output hashes agree. Cache keys include the direct artifact hashes, not just source text. Complete source/closure fingerprints are recorded as additional provenance, not a replacement for compiler checks.
3. Use serial bounded compilation following the accepted builder: one Lean process with a fixed 180-second/4-GiB cap per missing component; the sole ThetaCertificate5 exception is a fixed 600-second/6-GiB cap. Preserve each attempted source, command, logs, output hashes and return status in a new immutable receipt directory. Do not overwrite earlier attempts or silently count a timeout/failure as passed.
4. Compile the 41 preserved group aggregates in their declared contexts after their components are ready. Each group aggregate has a fixed 180-second/4-GiB cap. The single combined compatible aggregate attempt has a fixed 300-second/6-GiB cap. No automatic resource escalation is authorized by this plan. If it is impractical or fails, retain the runnable separated groups and report the exact tested boundary; do not weaken proofs or claim an all-in-one success.
5. Run complete selected-declaration axiom/type/body dependency audits for the tested contexts. Reject owned axioms, nonstandard axiom rows, missing modules, source drift and mismatched actual imports. Group audits use a fixed 180-second/4-GiB cap per audit; combined compatible audits, only after a successful aggregate, use a fixed 300-second/6-GiB cap per audit. Authenticate the imported external artifacts and pins used by each checked target.
6. Publish the configured workspace graph, source/version ledger, reproduction instructions and exact verified build certificate only after actual checks and independent review. Distinguish reused component evidence, newly compiled components, fresh aggregate/connection checks, untested targets and mathematical theorem closure.

## Mathematical connection discipline

Existing source imports and exact theorem-level implication links provide the initial graph. A workspace connection is not a new theorem proving an outstanding premise. G1 remains complete at its contract; the new G2 universal criterion is complete at its scoped iff; complete timed G2, broader G5 M 3/HG, G6/G7 full assemblies, NANUQ geometry and original G3/G4 retain their separate status. No assumed desired-law field, axiomatized interface, global source renaming or forced import collision is an acceptable integration shortcut.

The accepted timed-G2 final contract and unaccepted marked-trace draft are preserved separately and excluded from the accepted 1123-version count. G3/G4 work continues in its existing lanes. This integration performs no biological solver run and no external Jordan execution.
