import AllLevelParameterDomain
import AnchorAdjacency
import AnchorCanonicalOrder
import AnchorComposition
import AnchorCompression
import AnchorCompressionOrder
import AnchorIndexTransport
import AnchorLeafPosition
import AnchorMetricOrder
import AnchorNondegenerate
import AnchorPortCounts
import AnchorPortFibers
import AnchorPortPatterns
import AnchorPortValues
import AnchorThetaBridge
import CircularBasis
import CircularBoundary
import CircularComposition
import CircularDecomposition
import CircularMixture
import CircularRestriction
import CircularSupportCompression
import CircularThetaCuts
import CircularThetaSupport
import E8CertificateStability
import E8DeterministicTopKCertificate
import E8ExactResidualMass
import E8FiniteTracebackLaw
import E8GridTracebackBridge
import E8MidpointGridLaw
import E8MidpointGridTV
import E8MidpointProductionKernel
import E8ObservablePrefixLaw
import E8SCFG2ProviderBoundaryContract
import E8SCFG2RuntimeChildAdapter
import E8SamplerBridgeAudit
import E8ScheduledDerivationSum
import E8ScheduledHypergraphCorrectness
import E8ScheduledObserverFrame
import E8SelectedMassInclusionExclusion
import E8SourceVBranchBound
import E8StrictPrefixSelector
import E8SupportedTracebackLaw
import E8TracebackCallRanks
import E8TracebackErrorComposition
import E8UniformPrefixLaw
import ExponentialClockMoments
import G1SharedRegisterStress
import G2LiveLineageRouting
import G3AllResidueNormalIdentities
import G3AllResiduePositivity
import G3BernoulliCriticalNumerators
import G3BernoulliDerivatives
import G3BernoulliVerticalExclusion
import G3CapSixDeterminant
import G3FiniteMomentBarrier
import G3FixedDegreeResultants
import G4AllRootBinomialCompression
import G4AllRootPairClocks
import G4BalancedForestIdentity
import G4FourRootPositivity
import G4IndependentRoutingBridge
import G4KingmanHankelObstruction
import G4OrdinaryTripletReadout
import G4PathResolvedMeasurement
import G4TwoRootSourceStopping
import G5ActualComponentSupport
import G5BoundedExactBlock
import G5BridgeBarrier
import G5BridgeComponentEntries
import G5CalendarRoutes
import G5ComponentCalendarCoverage
import G5CoupledGroupSemantics
import G5CoupledQuartetKernel
import G5CurrentPortTwoPositions
import G5CutChildNecessity
import G5ExponentialGermIdentification
import G5FairMomentQuartetTransport
import G5FairOriginalCoinLaw
import G5FairSelectorMoments
import G5FourGroupCriterion
import G5FourGroupSupportCases
import G5GroupRelabeling
import G5MinimalGraphInterface
import G5NonbridgeRouteBound
import G5OneIntersectionCase
import G5OriginalCoinPMF
import G5OriginalRouteHazard
import G5OriginalTipCurrentSupport
import G5PairMomentCases
import G5PairOnlySureBlockChronology
import G5ParentChoiceCalendar
import G5ParentPositionPushforward
import G5ProtectiveBlock
import G5RootRouteCurrentSupport
import G5SafePastHybridDisjointness
import G5SafePastMeetingPermanence
import G5ThreeGroupKernel
import G5TwoIntersectionCase
import G5UnknownRateSupport
import G6BridgeCannotEnterHybrid
import G7OriginalCensus
import GraphBlobLeaves
import GraphBlobMedian
import GraphBlobOrientation
import GraphBlobPorts
import GraphBlobs
import GraphBridgeSplits
import GraphCuts
import GraphGalls
import GraphLeaves
import GraphMedianUnique
import GraphPortConsequences
import GraphPortFibers
import GraphPortTransport
import GraphPorts
import GraphQuartetBridge
import GraphQuartetExistence
import GraphSwitching
import GraphSwitchingChoices
import GraphSwitchingCuts
import GraphSwitchingDegree
import GraphSwitchingExistence
import GraphSwitchingFinite
import GraphTreePorts
import IntervalBoundary
import KingmanFiniteChernoff
import KingmanFiniteClockTail
import PairingBridge
import PairingCore
import PairingGARG
import PairingObservation
import PairingObservationAudit
import PedigreeBlockAudit
import PedigreeBlockDependence
import PedigreeBlockGraph
import PedigreeBlockModel
import PedigreeBlockObservation
import PedigreeBlockProbability
import PedigreeBlockRecovery
import QuartetComposition
import QuartetCompositionDependent
import QuartetSemantics
import RawNanuq
import RawSourceAnchorLocalization
import RealBridges
import RepresentationTransport
import SamuelAlexanderResearch
import SamuelAlexanderResearch.AncestralRestriction
import SamuelAlexanderResearch.AncestryContraction
import SamuelAlexanderResearch.AncestryViews
import SamuelAlexanderResearch.BinaryAvoidance
import SamuelAlexanderResearch.BinaryPopulation
import SamuelAlexanderResearch.BirthOrder
import SamuelAlexanderResearch.BoundaryRepair
import SamuelAlexanderResearch.CapTwo
import SamuelAlexanderResearch.CapTwoSpecies
import SamuelAlexanderResearch.DegreeBounds
import SamuelAlexanderResearch.DigitRecurrence
import SamuelAlexanderResearch.FiniteAvoidance
import SamuelAlexanderResearch.FiniteEditAlgorithm
import SamuelAlexanderResearch.FiniteEditBranch
import SamuelAlexanderResearch.FiniteEditExact
import SamuelAlexanderResearch.FiniteEditGap
import SamuelAlexanderResearch.FiniteEditOptimum
import SamuelAlexanderResearch.FiniteEditStability
import SamuelAlexanderResearch.FiniteHistoryCompletion
import SamuelAlexanderResearch.FinitePhasePaths
import SamuelAlexanderResearch.FiniteStatePeriodicity
import SamuelAlexanderResearch.FixedGenderLift
import SamuelAlexanderResearch.FixedGenderReindex
import SamuelAlexanderResearch.FullHeight
import SamuelAlexanderResearch.GeneralRigidity
import SamuelAlexanderResearch.GeneralRootObstruction
import SamuelAlexanderResearch.HistoryProjection
import SamuelAlexanderResearch.InfiniteConservation
import SamuelAlexanderResearch.LayeredUnavoidability
import SamuelAlexanderResearch.MinimalCrossing
import SamuelAlexanderResearch.ObservationPrediction
import SamuelAlexanderResearch.PhaseExtremal
import SamuelAlexanderResearch.PhaseHeight
import SamuelAlexanderResearch.PhaseShift
import SamuelAlexanderResearch.PopulationCounting
import SamuelAlexanderResearch.PopulationReindex
import SamuelAlexanderResearch.PortDynamics
import SamuelAlexanderResearch.PositiveUnavoidability
import SamuelAlexanderResearch.ProductiveCore
import SamuelAlexanderResearch.QuantitativeAvoidance
import SamuelAlexanderResearch.QuantitativeModulus
import SamuelAlexanderResearch.RootObstruction
import SamuelAlexanderResearch.SharpCorollaries
import SamuelAlexanderResearch.SharpThueMorse
import SamuelAlexanderResearch.SlowAvoidance
import SamuelAlexanderResearch.SpeciesAdapter
import SamuelAlexanderResearch.SpeciesBridge
import SamuelAlexanderResearch.SpeciesCones
import SamuelAlexanderResearch.SpeciesGlobalIAP
import SamuelAlexanderResearch.SpeciesRootCriterion
import SamuelAlexanderResearch.StatefulCA
import SamuelAlexanderResearch.StaticMixing
import SamuelAlexanderResearch.ThueMorseBits
import SamuelAlexanderResearch.ThueMorseBound
import SamuelAlexanderResearch.ThueMorseWindow
import SourceBlobFacts
import SourceCompositionBridge
import SourceFacts
import SourceForestKingmanPopulationProjection
import SourceForestKingmanProjection
import SourceLabelledForest
import SourceNetwork
import SourceQuartetRelation
import SourceQuartetSymmetry
import SourceResolve
import SplitReconstruction
import ThetaArmMetric
import ThetaArmOrder
import ThetaBumpedMetric
import ThetaCertificate1
import ThetaCertificate2
import ThetaCertificate3
import ThetaCertificate4
import ThetaCertificate5
import ThetaCompressedSurjective
import ThetaCompression
import ThetaDisplayedSemantics
import ThetaEdgeQuartet
import ThetaFinite
import ThetaFiniteSoundness
import ThetaPathLengths
import ThetaPathMembership
import ThetaQuartetEdge
import ThetaQuartetOrder
import ThetaQuartetSymmetry
import ThetaQuartetValidity
import ThetaSemanticsBridge
import ThetaSourceExact
import ThetaSupport
import ThetaSupportCertificate1
import ThetaSupportCertificate2
import ThetaSwitchingEdges
import ThetaWitnessSymmetry
import TreePathCounting
import TwoSwitchings
import UnifiedLean
import UnifiedLean.Audits.ResearchGoalAudit
import UnifiedLean.Source.ControlledUnrankedSourceProjectivity
import UnifiedLean.Source.E8PaperGammaAdmission
import UnifiedLean.Source.E8PaperObservableBridge
import UnifiedLean.Source.E8SCFG2BEOwnership
import UnifiedLean.Source.E8SCFG2PartnerAdmission
import UnifiedLean.Source.E8SCFG2RootCarrier
import UnifiedLean.Source.E8SCFG2RootEventDecoder
import UnifiedLean.Source.E8SCFG2ScaffoldScan
import UnifiedLean.Source.FiniteGenealogyEncoding
import UnifiedLean.Source.FiniteSourceSnapshot
import UnifiedLean.Source.MatrixProjectionExponential
import UnifiedLean.Source.NativeCommonPairGerm
import UnifiedLean.Source.NativeCurrentPortCompiler
import UnifiedLean.Source.NativeFairCurrentPosition
import UnifiedLean.Source.NativeFairSelectorAssembly
import UnifiedLean.Source.NativeIndependentPairMixture
import UnifiedLean.Source.NativePairCalendarObservation
import UnifiedLean.Source.NativePairClockLaw
import UnifiedLean.Source.NativeParentRouting
import UnifiedLean.Source.NativeSafePastGerm
import UnifiedLean.Source.OriginalFixedIDControls
import UnifiedLean.Source.SourceActualHoldingClocks
import UnifiedLean.Source.SourceAncestralAbsorption
import UnifiedLean.Source.SourceAncestralCompletion
import UnifiedLean.Source.SourceAncestralDrift
import UnifiedLean.Source.SourceBoundaryKernels
import UnifiedLean.Source.SourceBoundaryLocations
import UnifiedLean.Source.SourceBoundaryProjection
import UnifiedLean.Source.SourceCalendarCompatibility
import UnifiedLean.Source.SourceCalendarCompiler
import UnifiedLean.Source.SourceCalendarPhysicalSupport
import UnifiedLean.Source.SourceCalendarTiming
import UnifiedLean.Source.SourceCompletedUnrankedTree
import UnifiedLean.Source.SourceCompletionHarmonic
import UnifiedLean.Source.SourceCopyCarrierTransport
import UnifiedLean.Source.SourceCrossCarrierBoundary
import UnifiedLean.Source.SourceCrossCarrierEpoch
import UnifiedLean.Source.SourceCrossCarrierNatural
import UnifiedLean.Source.SourceCrossCarrierProgram
import UnifiedLean.Source.SourceDestinationClockReset
import UnifiedLean.Source.SourceEmbeddedJumpLaw
import UnifiedLean.Source.SourceEpochRenewal
import UnifiedLean.Source.SourceEpochSemigroup
import UnifiedLean.Source.SourceEventualCompletionLimit
import UnifiedLean.Source.SourceExponentialRace
import UnifiedLean.Source.SourceExponentialRaceDensity
import UnifiedLean.Source.SourceExponentialResiduals
import UnifiedLean.Source.SourceFiniteJumpExpansion
import UnifiedLean.Source.SourceFiniteProjection
import UnifiedLean.Source.SourceFirstMarkDistribution
import UnifiedLean.Source.SourceFirstMergerMark
import UnifiedLean.Source.SourceForestCommonPulse
import UnifiedLean.Source.SourceForestGeneratorIntertwining
import UnifiedLean.Source.SourceForestIntrinsicGenerator
import UnifiedLean.Source.SourceForestPulseMeasure
import UnifiedLean.Source.SourceForestPulseTransport
import UnifiedLean.Source.SourceForestSilentPruning
import UnifiedLean.Source.SourceGeneratorExponential
import UnifiedLean.Source.SourceInitializedCalendar
import UnifiedLean.Source.SourceLiteralClockEndpoint
import UnifiedLean.Source.SourceMergerClockCatalogue
import UnifiedLean.Source.SourceNaturalCompletedLimit
import UnifiedLean.Source.SourceNaturalInitialization
import UnifiedLean.Source.SourcePoissonExponential
import UnifiedLean.Source.SourcePoissonKernel
import UnifiedLean.Source.SourceProgramTransport
import UnifiedLean.Source.SourceRaceWinnerSelection
import UnifiedLean.Source.SourceSmallCarrierGenerator
import UnifiedLean.Source.SourceSmallCarrierPulse
import UnifiedLean.Source.SourceStepGeneratorBinding
import UnifiedLean.Source.SourceUnrankedAllPanels
import UnifiedLean.Source.SourceUnrankedCopyProjectivity
import UnifiedLean.Source.SourceWinningClockReset
import UnifiedLean.Source.UniformizedSourceStep
import UnifiedLean.Source.UnrankedGenealogyObservation
import VerifiedAlgebraComponents
import VerifiedAllRootComponents
import VerifiedBridgeEntry
import VerifiedClockTailComponents
import VerifiedComponents
import VerifiedFullComponentCheckpoint
import VerifiedLeanFirstCheckpoint
import VerifiedRoutingBridge
import WeightedAnchor
import WeightedCoefficients
import WeightedOrderedPairs
import WeightedProperties
import WeightedRestriction
import WeightedSmallPorts
import WeightedSource
import WongAlexander
import WongGARG
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let environment ← getEnv
  let names : Array String := #["AllLevelParameterDomain", "AnchorAdjacency", "AnchorCanonicalOrder", "AnchorComposition", "AnchorCompression", "AnchorCompressionOrder", "AnchorIndexTransport", "AnchorLeafPosition", "AnchorMetricOrder", "AnchorNondegenerate", "AnchorPortCounts", "AnchorPortFibers", "AnchorPortPatterns", "AnchorPortValues", "AnchorThetaBridge", "CircularBasis", "CircularBoundary", "CircularComposition", "CircularDecomposition", "CircularMixture", "CircularRestriction", "CircularSupportCompression", "CircularThetaCuts", "CircularThetaSupport", "E8CertificateStability", "E8DeterministicTopKCertificate", "E8ExactResidualMass", "E8FiniteTracebackLaw", "E8GridTracebackBridge", "E8MidpointGridLaw", "E8MidpointGridTV", "E8MidpointProductionKernel", "E8ObservablePrefixLaw", "E8SCFG2ProviderBoundaryContract", "E8SCFG2RuntimeChildAdapter", "E8SamplerBridgeAudit", "E8ScheduledDerivationSum", "E8ScheduledHypergraphCorrectness", "E8ScheduledObserverFrame", "E8SelectedMassInclusionExclusion", "E8SourceVBranchBound", "E8StrictPrefixSelector", "E8SupportedTracebackLaw", "E8TracebackCallRanks", "E8TracebackErrorComposition", "E8UniformPrefixLaw", "ExponentialClockMoments", "G1SharedRegisterStress", "G2LiveLineageRouting", "G3AllResidueNormalIdentities", "G3AllResiduePositivity", "G3BernoulliCriticalNumerators", "G3BernoulliDerivatives", "G3BernoulliVerticalExclusion", "G3CapSixDeterminant", "G3FiniteMomentBarrier", "G3FixedDegreeResultants", "G4AllRootBinomialCompression", "G4AllRootPairClocks", "G4BalancedForestIdentity", "G4FourRootPositivity", "G4IndependentRoutingBridge", "G4KingmanHankelObstruction", "G4OrdinaryTripletReadout", "G4PathResolvedMeasurement", "G4TwoRootSourceStopping", "G5ActualComponentSupport", "G5BoundedExactBlock", "G5BridgeBarrier", "G5BridgeComponentEntries", "G5CalendarRoutes", "G5ComponentCalendarCoverage", "G5CoupledGroupSemantics", "G5CoupledQuartetKernel", "G5CurrentPortTwoPositions", "G5CutChildNecessity", "G5ExponentialGermIdentification", "G5FairMomentQuartetTransport", "G5FairOriginalCoinLaw", "G5FairSelectorMoments", "G5FourGroupCriterion", "G5FourGroupSupportCases", "G5GroupRelabeling", "G5MinimalGraphInterface", "G5NonbridgeRouteBound", "G5OneIntersectionCase", "G5OriginalCoinPMF", "G5OriginalRouteHazard", "G5OriginalTipCurrentSupport", "G5PairMomentCases", "G5PairOnlySureBlockChronology", "G5ParentChoiceCalendar", "G5ParentPositionPushforward", "G5ProtectiveBlock", "G5RootRouteCurrentSupport", "G5SafePastHybridDisjointness", "G5SafePastMeetingPermanence", "G5ThreeGroupKernel", "G5TwoIntersectionCase", "G5UnknownRateSupport", "G6BridgeCannotEnterHybrid", "G7OriginalCensus", "GraphBlobLeaves", "GraphBlobMedian", "GraphBlobOrientation", "GraphBlobPorts", "GraphBlobs", "GraphBridgeSplits", "GraphCuts", "GraphGalls", "GraphLeaves", "GraphMedianUnique", "GraphPortConsequences", "GraphPortFibers", "GraphPortTransport", "GraphPorts", "GraphQuartetBridge", "GraphQuartetExistence", "GraphSwitching", "GraphSwitchingChoices", "GraphSwitchingCuts", "GraphSwitchingDegree", "GraphSwitchingExistence", "GraphSwitchingFinite", "GraphTreePorts", "IntervalBoundary", "KingmanFiniteChernoff", "KingmanFiniteClockTail", "PairingBridge", "PairingCore", "PairingGARG", "PairingObservation", "PairingObservationAudit", "PedigreeBlockAudit", "PedigreeBlockDependence", "PedigreeBlockGraph", "PedigreeBlockModel", "PedigreeBlockObservation", "PedigreeBlockProbability", "PedigreeBlockRecovery", "QuartetComposition", "QuartetCompositionDependent", "QuartetSemantics", "RawNanuq", "RawSourceAnchorLocalization", "RealBridges", "RepresentationTransport", "SamuelAlexanderResearch", "SamuelAlexanderResearch.AncestralRestriction", "SamuelAlexanderResearch.AncestryContraction", "SamuelAlexanderResearch.AncestryViews", "SamuelAlexanderResearch.BinaryAvoidance", "SamuelAlexanderResearch.BinaryPopulation", "SamuelAlexanderResearch.BirthOrder", "SamuelAlexanderResearch.BoundaryRepair", "SamuelAlexanderResearch.CapTwo", "SamuelAlexanderResearch.CapTwoSpecies", "SamuelAlexanderResearch.DegreeBounds", "SamuelAlexanderResearch.DigitRecurrence", "SamuelAlexanderResearch.FiniteAvoidance", "SamuelAlexanderResearch.FiniteEditAlgorithm", "SamuelAlexanderResearch.FiniteEditBranch", "SamuelAlexanderResearch.FiniteEditExact", "SamuelAlexanderResearch.FiniteEditGap", "SamuelAlexanderResearch.FiniteEditOptimum", "SamuelAlexanderResearch.FiniteEditStability", "SamuelAlexanderResearch.FiniteHistoryCompletion", "SamuelAlexanderResearch.FinitePhasePaths", "SamuelAlexanderResearch.FiniteStatePeriodicity", "SamuelAlexanderResearch.FixedGenderLift", "SamuelAlexanderResearch.FixedGenderReindex", "SamuelAlexanderResearch.FullHeight", "SamuelAlexanderResearch.GeneralRigidity", "SamuelAlexanderResearch.GeneralRootObstruction", "SamuelAlexanderResearch.HistoryProjection", "SamuelAlexanderResearch.InfiniteConservation", "SamuelAlexanderResearch.LayeredUnavoidability", "SamuelAlexanderResearch.MinimalCrossing", "SamuelAlexanderResearch.ObservationPrediction", "SamuelAlexanderResearch.PhaseExtremal", "SamuelAlexanderResearch.PhaseHeight", "SamuelAlexanderResearch.PhaseShift", "SamuelAlexanderResearch.PopulationCounting", "SamuelAlexanderResearch.PopulationReindex", "SamuelAlexanderResearch.PortDynamics", "SamuelAlexanderResearch.PositiveUnavoidability", "SamuelAlexanderResearch.ProductiveCore", "SamuelAlexanderResearch.QuantitativeAvoidance", "SamuelAlexanderResearch.QuantitativeModulus", "SamuelAlexanderResearch.RootObstruction", "SamuelAlexanderResearch.SharpCorollaries", "SamuelAlexanderResearch.SharpThueMorse", "SamuelAlexanderResearch.SlowAvoidance", "SamuelAlexanderResearch.SpeciesAdapter", "SamuelAlexanderResearch.SpeciesBridge", "SamuelAlexanderResearch.SpeciesCones", "SamuelAlexanderResearch.SpeciesGlobalIAP", "SamuelAlexanderResearch.SpeciesRootCriterion", "SamuelAlexanderResearch.StatefulCA", "SamuelAlexanderResearch.StaticMixing", "SamuelAlexanderResearch.ThueMorseBits", "SamuelAlexanderResearch.ThueMorseBound", "SamuelAlexanderResearch.ThueMorseWindow", "SourceBlobFacts", "SourceCompositionBridge", "SourceFacts", "SourceForestKingmanPopulationProjection", "SourceForestKingmanProjection", "SourceLabelledForest", "SourceNetwork", "SourceQuartetRelation", "SourceQuartetSymmetry", "SourceResolve", "SplitReconstruction", "ThetaArmMetric", "ThetaArmOrder", "ThetaBumpedMetric", "ThetaCertificate1", "ThetaCertificate2", "ThetaCertificate3", "ThetaCertificate4", "ThetaCertificate5", "ThetaCompressedSurjective", "ThetaCompression", "ThetaDisplayedSemantics", "ThetaEdgeQuartet", "ThetaFinite", "ThetaFiniteSoundness", "ThetaPathLengths", "ThetaPathMembership", "ThetaQuartetEdge", "ThetaQuartetOrder", "ThetaQuartetSymmetry", "ThetaQuartetValidity", "ThetaSemanticsBridge", "ThetaSourceExact", "ThetaSupport", "ThetaSupportCertificate1", "ThetaSupportCertificate2", "ThetaSwitchingEdges", "ThetaWitnessSymmetry", "TreePathCounting", "TwoSwitchings", "UnifiedLean", "UnifiedLean.Audits.ResearchGoalAudit", "UnifiedLean.Source.ControlledUnrankedSourceProjectivity", "UnifiedLean.Source.E8PaperGammaAdmission", "UnifiedLean.Source.E8PaperObservableBridge", "UnifiedLean.Source.E8SCFG2BEOwnership", "UnifiedLean.Source.E8SCFG2PartnerAdmission", "UnifiedLean.Source.E8SCFG2RootCarrier", "UnifiedLean.Source.E8SCFG2RootEventDecoder", "UnifiedLean.Source.E8SCFG2ScaffoldScan", "UnifiedLean.Source.FiniteGenealogyEncoding", "UnifiedLean.Source.FiniteSourceSnapshot", "UnifiedLean.Source.MatrixProjectionExponential", "UnifiedLean.Source.NativeCommonPairGerm", "UnifiedLean.Source.NativeCurrentPortCompiler", "UnifiedLean.Source.NativeFairCurrentPosition", "UnifiedLean.Source.NativeFairSelectorAssembly", "UnifiedLean.Source.NativeIndependentPairMixture", "UnifiedLean.Source.NativePairCalendarObservation", "UnifiedLean.Source.NativePairClockLaw", "UnifiedLean.Source.NativeParentRouting", "UnifiedLean.Source.NativeSafePastGerm", "UnifiedLean.Source.OriginalFixedIDControls", "UnifiedLean.Source.SourceActualHoldingClocks", "UnifiedLean.Source.SourceAncestralAbsorption", "UnifiedLean.Source.SourceAncestralCompletion", "UnifiedLean.Source.SourceAncestralDrift", "UnifiedLean.Source.SourceBoundaryKernels", "UnifiedLean.Source.SourceBoundaryLocations", "UnifiedLean.Source.SourceBoundaryProjection", "UnifiedLean.Source.SourceCalendarCompatibility", "UnifiedLean.Source.SourceCalendarCompiler", "UnifiedLean.Source.SourceCalendarPhysicalSupport", "UnifiedLean.Source.SourceCalendarTiming", "UnifiedLean.Source.SourceCompletedUnrankedTree", "UnifiedLean.Source.SourceCompletionHarmonic", "UnifiedLean.Source.SourceCopyCarrierTransport", "UnifiedLean.Source.SourceCrossCarrierBoundary", "UnifiedLean.Source.SourceCrossCarrierEpoch", "UnifiedLean.Source.SourceCrossCarrierNatural", "UnifiedLean.Source.SourceCrossCarrierProgram", "UnifiedLean.Source.SourceDestinationClockReset", "UnifiedLean.Source.SourceEmbeddedJumpLaw", "UnifiedLean.Source.SourceEpochRenewal", "UnifiedLean.Source.SourceEpochSemigroup", "UnifiedLean.Source.SourceEventualCompletionLimit", "UnifiedLean.Source.SourceExponentialRace", "UnifiedLean.Source.SourceExponentialRaceDensity", "UnifiedLean.Source.SourceExponentialResiduals", "UnifiedLean.Source.SourceFiniteJumpExpansion", "UnifiedLean.Source.SourceFiniteProjection", "UnifiedLean.Source.SourceFirstMarkDistribution", "UnifiedLean.Source.SourceFirstMergerMark", "UnifiedLean.Source.SourceForestCommonPulse", "UnifiedLean.Source.SourceForestGeneratorIntertwining", "UnifiedLean.Source.SourceForestIntrinsicGenerator", "UnifiedLean.Source.SourceForestPulseMeasure", "UnifiedLean.Source.SourceForestPulseTransport", "UnifiedLean.Source.SourceForestSilentPruning", "UnifiedLean.Source.SourceGeneratorExponential", "UnifiedLean.Source.SourceInitializedCalendar", "UnifiedLean.Source.SourceLiteralClockEndpoint", "UnifiedLean.Source.SourceMergerClockCatalogue", "UnifiedLean.Source.SourceNaturalCompletedLimit", "UnifiedLean.Source.SourceNaturalInitialization", "UnifiedLean.Source.SourcePoissonExponential", "UnifiedLean.Source.SourcePoissonKernel", "UnifiedLean.Source.SourceProgramTransport", "UnifiedLean.Source.SourceRaceWinnerSelection", "UnifiedLean.Source.SourceSmallCarrierGenerator", "UnifiedLean.Source.SourceSmallCarrierPulse", "UnifiedLean.Source.SourceStepGeneratorBinding", "UnifiedLean.Source.SourceUnrankedAllPanels", "UnifiedLean.Source.SourceUnrankedCopyProjectivity", "UnifiedLean.Source.SourceWinningClockReset", "UnifiedLean.Source.UniformizedSourceStep", "UnifiedLean.Source.UnrankedGenealogyObservation", "VerifiedAlgebraComponents", "VerifiedAllRootComponents", "VerifiedBridgeEntry", "VerifiedClockTailComponents", "VerifiedComponents", "VerifiedFullComponentCheckpoint", "VerifiedLeanFirstCheckpoint", "VerifiedRoutingBridge", "WeightedAnchor", "WeightedCoefficients", "WeightedOrderedPairs", "WeightedProperties", "WeightedRestriction", "WeightedSmallPorts", "WeightedSource", "WongAlexander", "WongGARG"]
  let imported := environment.header.moduleNames.map Name.toString
  let indices := environment.header.moduleNames.map (fun n => names.contains n.toString)
  let mut declarations : Array Json := #[]
  let mut invalid : Array Json := #[]
  let mut ownedAxioms : Array String := #[]
  let mut theorems : Nat := 0
  for (name, information) in environment.constants do
    if let some index := environment.getModuleIdxFor? name then
      if indices[index.toNat]! then
        let axioms ← collectAxioms name
        let kind := match information with
          | .thmInfo _ => "theorem"
          | .axiomInfo _ => "axiom"
          | .defnInfo _ => "definition"
          | .opaqueInfo _ => "opaque"
          | .inductInfo _ => "inductive"
          | .ctorInfo _ => "constructor"
          | .recInfo _ => "recursor"
          | .quotInfo _ => "quotient"
        if kind == "theorem" then theorems := theorems + 1
        if kind == "axiom" then ownedAxioms := ownedAxioms.push name.toString
        let refs := match information.value? (allowOpaque := true) with
          | some expression => expression.getUsedConstants.map Name.toString
          | none => #[]
        let record := Json.mkObj [
          ("module", toJson imported[index.toNat]!), ("name", toJson name.toString),
          ("kind", toJson kind), ("axioms", toJson (axioms.map Name.toString)),
          ("type_references", toJson (information.type.getUsedConstants.map Name.toString)),
          ("body_references", toJson refs)]
        declarations := declarations.push record
        if axioms.any (fun ax => ! #[``propext, ``Classical.choice, ``Quot.sound].contains ax) then
          invalid := invalid.push record
  let missing := names.filter (fun n => ! imported.contains n)
  let result := Json.mkObj [
    ("selected_modules", toJson names), ("all_imported_module_names", toJson imported),
    ("declaration_count", toJson declarations.size),
    ("theorem_declaration_count", toJson theorems), ("owned_axioms", toJson ownedAxioms),
    ("nonstandard_axiom_rows", toJson invalid), ("missing_modules", toJson missing),
    ("declarations", toJson declarations)]
  liftIO <| IO.FS.writeFile "AUDIT-RESULT.json" result.pretty
  logInfo m!"Fresh closure: {declarations.size} declarations, {theorems} theorems, {ownedAxioms.size} owned axioms, {invalid.size} nonstandard rows, {missing.size} missing modules"
  unless ownedAxioms.isEmpty && invalid.isEmpty && missing.isEmpty do
    throwError "Fresh complete closure audit failed"
