import AnchorReduction
import AnchorUnboundedSupport
import AnchorUnboundedTheorem
import BoundedThetaTheorem
import CanonicalTheta
import ThetaCertificate
import ThetaCertificate6
import ThetaDeletedHybrid
import ThetaFiniteEndpoint
import ThetaKernelSupport_0_0_0_3
import ThetaKernelSupport_0_0_0_4
import ThetaKernelSupport_0_0_0_5
import ThetaKernelSupport_0_0_0_6
import ThetaKernelSupport_0_0_1_2
import ThetaKernelSupport_0_0_1_3
import ThetaKernelSupport_0_0_1_4
import ThetaKernelSupport_0_0_1_5
import ThetaKernelSupport_0_0_2_1
import ThetaKernelSupport_0_0_2_2
import ThetaKernelSupport_0_0_2_3
import ThetaKernelSupport_0_0_2_4
import ThetaKernelSupport_0_0_3_0
import ThetaKernelSupport_0_0_3_1
import ThetaKernelSupport_0_0_3_2
import ThetaKernelSupport_0_0_3_3
import ThetaKernelSupport_0_0_4_0
import ThetaKernelSupport_0_0_4_1
import ThetaKernelSupport_0_0_4_2
import ThetaKernelSupport_0_0_5_0
import ThetaKernelSupport_0_0_5_1
import ThetaKernelSupport_0_0_6_0
import ThetaKernelSupport_0_1_0_2
import ThetaKernelSupport_0_1_0_3
import ThetaKernelSupport_0_1_0_4
import ThetaKernelSupport_0_1_0_5
import ThetaKernelSupport_0_1_1_1
import ThetaKernelSupport_0_1_1_2
import ThetaKernelSupport_0_1_1_3
import ThetaKernelSupport_0_1_1_4
import ThetaKernelSupport_0_1_2_0
import ThetaKernelSupport_0_1_2_1
import ThetaKernelSupport_0_1_2_2
import ThetaKernelSupport_0_1_2_3
import ThetaKernelSupport_0_1_3_0
import ThetaKernelSupport_0_1_3_1
import ThetaKernelSupport_0_1_3_2
import ThetaKernelSupport_0_1_4_0
import ThetaKernelSupport_0_1_4_1
import ThetaKernelSupport_0_1_5_0
import ThetaKernelSupport_0_2_0_1
import ThetaKernelSupport_0_2_0_2
import ThetaKernelSupport_0_2_0_3
import ThetaKernelSupport_0_2_0_4
import ThetaKernelSupport_0_2_1_0
import ThetaKernelSupport_0_2_1_1
import ThetaKernelSupport_0_2_1_2
import ThetaKernelSupport_0_2_1_3
import ThetaKernelSupport_0_2_2_0
import ThetaKernelSupport_0_2_2_1
import ThetaKernelSupport_0_2_2_2
import ThetaKernelSupport_0_2_3_0
import ThetaKernelSupport_0_2_3_1
import ThetaKernelSupport_0_2_4_0
import ThetaKernelSupport_0_3_0_0
import ThetaKernelSupport_0_3_0_1
import ThetaKernelSupport_0_3_0_2
import ThetaKernelSupport_0_3_0_3
import ThetaKernelSupport_0_3_1_0
import ThetaKernelSupport_0_3_1_1
import ThetaKernelSupport_0_3_1_2
import ThetaKernelSupport_0_3_2_0
import ThetaKernelSupport_0_3_2_1
import ThetaKernelSupport_0_3_3_0
import ThetaKernelSupport_0_4_0_0
import ThetaKernelSupport_0_4_0_1
import ThetaKernelSupport_0_4_0_2
import ThetaKernelSupport_0_4_1_0
import ThetaKernelSupport_0_4_1_1
import ThetaKernelSupport_0_4_2_0
import ThetaKernelSupport_0_5_0_0
import ThetaKernelSupport_0_5_0_1
import ThetaKernelSupport_0_5_1_0
import ThetaKernelSupport_0_6_0_0
import ThetaKernelSupport_1_0_0_2
import ThetaKernelSupport_1_0_0_3
import ThetaKernelSupport_1_0_0_4
import ThetaKernelSupport_1_0_0_5
import ThetaKernelSupport_1_0_1_1
import ThetaKernelSupport_1_0_1_2
import ThetaKernelSupport_1_0_1_3
import ThetaKernelSupport_1_0_1_4
import ThetaKernelSupport_1_0_2_0
import ThetaKernelSupport_1_0_2_1
import ThetaKernelSupport_1_0_2_2
import ThetaKernelSupport_1_0_2_3
import ThetaKernelSupport_1_0_3_0
import ThetaKernelSupport_1_0_3_1
import ThetaKernelSupport_1_0_3_2
import ThetaKernelSupport_1_0_4_0
import ThetaKernelSupport_1_0_4_1
import ThetaKernelSupport_1_0_5_0
import ThetaKernelSupport_1_1_0_1
import ThetaKernelSupport_1_1_0_2
import ThetaKernelSupport_1_1_0_3
import ThetaKernelSupport_1_1_0_4
import ThetaKernelSupport_1_1_1_0
import ThetaKernelSupport_1_1_1_1
import ThetaKernelSupport_1_1_1_2
import ThetaKernelSupport_1_1_1_3
import ThetaKernelSupport_1_1_2_0
import ThetaKernelSupport_1_1_2_1
import ThetaKernelSupport_1_1_2_2
import ThetaKernelSupport_1_1_3_0
import ThetaKernelSupport_1_1_3_1
import ThetaKernelSupport_1_1_4_0
import ThetaKernelSupport_1_2_0_0
import ThetaKernelSupport_1_2_0_1
import ThetaKernelSupport_1_2_0_2
import ThetaKernelSupport_1_2_0_3
import ThetaKernelSupport_1_2_1_0
import ThetaKernelSupport_1_2_1_1
import ThetaKernelSupport_1_2_1_2
import ThetaKernelSupport_1_2_2_0
import ThetaKernelSupport_1_2_2_1
import ThetaKernelSupport_1_2_3_0
import ThetaKernelSupport_1_3_0_0
import ThetaKernelSupport_1_3_0_1
import ThetaKernelSupport_1_3_0_2
import ThetaKernelSupport_1_3_1_0
import ThetaKernelSupport_1_3_1_1
import ThetaKernelSupport_1_3_2_0
import ThetaKernelSupport_1_4_0_0
import ThetaKernelSupport_1_4_0_1
import ThetaKernelSupport_1_4_1_0
import ThetaKernelSupport_1_5_0_0
import ThetaKernelSupport_2_0_0_1
import ThetaKernelSupport_2_0_0_2
import ThetaKernelSupport_2_0_0_3
import ThetaKernelSupport_2_0_0_4
import ThetaKernelSupport_2_0_1_0
import ThetaKernelSupport_2_0_1_1
import ThetaKernelSupport_2_0_1_2
import ThetaKernelSupport_2_0_1_3
import ThetaKernelSupport_2_0_2_0
import ThetaKernelSupport_2_0_2_1
import ThetaKernelSupport_2_0_2_2
import ThetaKernelSupport_2_0_3_0
import ThetaKernelSupport_2_0_3_1
import ThetaKernelSupport_2_0_4_0
import ThetaKernelSupport_2_1_0_0
import ThetaKernelSupport_2_1_0_1
import ThetaKernelSupport_2_1_0_2
import ThetaKernelSupport_2_1_0_3
import ThetaKernelSupport_2_1_1_0
import ThetaKernelSupport_2_1_1_1
import ThetaKernelSupport_2_1_1_2
import ThetaKernelSupport_2_1_2_0
import ThetaKernelSupport_2_1_2_1
import ThetaKernelSupport_2_1_3_0
import ThetaKernelSupport_2_2_0_0
import ThetaKernelSupport_2_2_0_1
import ThetaKernelSupport_2_2_0_2
import ThetaKernelSupport_2_2_1_0
import ThetaKernelSupport_2_2_1_1
import ThetaKernelSupport_2_2_2_0
import ThetaKernelSupport_2_3_0_0
import ThetaKernelSupport_2_3_0_1
import ThetaKernelSupport_2_3_1_0
import ThetaKernelSupport_2_4_0_0
import ThetaKernelSupport_3_0_0_0
import ThetaKernelSupport_3_0_0_1
import ThetaKernelSupport_3_0_0_2
import ThetaKernelSupport_3_0_0_3
import ThetaKernelSupport_3_0_1_0
import ThetaKernelSupport_3_0_1_1
import ThetaKernelSupport_3_0_1_2
import ThetaKernelSupport_3_0_2_0
import ThetaKernelSupport_3_0_2_1
import ThetaKernelSupport_3_0_3_0
import ThetaKernelSupport_3_1_0_0
import ThetaKernelSupport_3_1_0_1
import ThetaKernelSupport_3_1_0_2
import ThetaKernelSupport_3_1_1_0
import ThetaKernelSupport_3_1_1_1
import ThetaKernelSupport_3_1_2_0
import ThetaKernelSupport_3_2_0_0
import ThetaKernelSupport_3_2_0_1
import ThetaKernelSupport_3_2_1_0
import ThetaKernelSupport_3_3_0_0
import ThetaKernelSupport_4_0_0_0
import ThetaKernelSupport_4_0_0_1
import ThetaKernelSupport_4_0_0_2
import ThetaKernelSupport_4_0_1_0
import ThetaKernelSupport_4_0_1_1
import ThetaKernelSupport_4_0_2_0
import ThetaKernelSupport_4_1_0_0
import ThetaKernelSupport_4_1_0_1
import ThetaKernelSupport_4_1_1_0
import ThetaKernelSupport_4_2_0_0
import ThetaKernelSupport_5_0_0_0
import ThetaKernelSupport_5_0_0_1
import ThetaKernelSupport_5_0_1_0
import ThetaKernelSupport_5_1_0_0
import ThetaKernelSupport_6_0_0_0
import ThetaKernelTemplate_0_0_0_6
import ThetaKernelTemplate_0_0_1_5
import ThetaKernelTemplate_0_0_2_4
import ThetaKernelTemplate_0_0_3_3
import ThetaKernelTemplate_0_0_4_2
import ThetaKernelTemplate_0_0_5_1
import ThetaKernelTemplate_0_0_6_0
import ThetaKernelTemplate_0_1_0_5
import ThetaKernelTemplate_0_1_1_4
import ThetaKernelTemplate_0_1_2_3
import ThetaKernelTemplate_0_1_3_2
import ThetaKernelTemplate_0_1_4_1
import ThetaKernelTemplate_0_1_5_0
import ThetaKernelTemplate_0_2_0_4
import ThetaKernelTemplate_0_2_1_3
import ThetaKernelTemplate_0_2_2_2
import ThetaKernelTemplate_0_2_3_1
import ThetaKernelTemplate_0_2_4_0
import ThetaKernelTemplate_0_3_0_3
import ThetaKernelTemplate_0_3_1_2
import ThetaKernelTemplate_0_3_2_1
import ThetaKernelTemplate_0_3_3_0
import ThetaKernelTemplate_0_4_0_2
import ThetaKernelTemplate_0_4_1_1
import ThetaKernelTemplate_0_4_2_0
import ThetaKernelTemplate_0_5_0_1
import ThetaKernelTemplate_0_5_1_0
import ThetaKernelTemplate_0_6_0_0
import ThetaKernelTemplate_1_0_0_5
import ThetaKernelTemplate_1_0_1_4
import ThetaKernelTemplate_1_0_2_3
import ThetaKernelTemplate_1_0_3_2
import ThetaKernelTemplate_1_0_4_1
import ThetaKernelTemplate_1_0_5_0
import ThetaKernelTemplate_1_1_0_4
import ThetaKernelTemplate_1_1_1_3
import ThetaKernelTemplate_1_1_2_2
import ThetaKernelTemplate_1_1_3_1
import ThetaKernelTemplate_1_1_4_0
import ThetaKernelTemplate_1_2_0_3
import ThetaKernelTemplate_1_2_1_2
import ThetaKernelTemplate_1_2_2_1
import ThetaKernelTemplate_1_2_3_0
import ThetaKernelTemplate_1_3_0_2
import ThetaKernelTemplate_1_3_1_1
import ThetaKernelTemplate_1_3_2_0
import ThetaKernelTemplate_1_4_0_1
import ThetaKernelTemplate_1_4_1_0
import ThetaKernelTemplate_1_5_0_0
import ThetaKernelTemplate_2_0_0_4
import ThetaKernelTemplate_2_0_1_3
import ThetaKernelTemplate_2_0_2_2
import ThetaKernelTemplate_2_0_3_1
import ThetaKernelTemplate_2_0_4_0
import ThetaKernelTemplate_2_1_0_3
import ThetaKernelTemplate_2_1_1_2
import ThetaKernelTemplate_2_1_2_1
import ThetaKernelTemplate_2_1_3_0
import ThetaKernelTemplate_2_2_0_2
import ThetaKernelTemplate_2_2_1_1
import ThetaKernelTemplate_2_2_2_0
import ThetaKernelTemplate_2_3_0_1
import ThetaKernelTemplate_2_3_1_0
import ThetaKernelTemplate_2_4_0_0
import ThetaKernelTemplate_3_0_0_3
import ThetaKernelTemplate_3_0_1_2
import ThetaKernelTemplate_3_0_2_1
import ThetaKernelTemplate_3_0_3_0
import ThetaKernelTemplate_3_1_0_2
import ThetaKernelTemplate_3_1_1_1
import ThetaKernelTemplate_3_1_2_0
import ThetaKernelTemplate_3_2_0_1
import ThetaKernelTemplate_3_2_1_0
import ThetaKernelTemplate_3_3_0_0
import ThetaKernelTemplate_4_0_0_2
import ThetaKernelTemplate_4_0_1_1
import ThetaKernelTemplate_4_0_2_0
import ThetaKernelTemplate_4_1_0_1
import ThetaKernelTemplate_4_1_1_0
import ThetaKernelTemplate_4_2_0_0
import ThetaKernelTemplate_5_0_0_1
import ThetaKernelTemplate_5_0_1_0
import ThetaKernelTemplate_5_1_0_0
import ThetaKernelTemplate_6_0_0_0
import ThetaRepair
import ThetaSourceUnbounded
import ThetaSupportCertificate
import ThetaSupportCertificate3
import ThetaSupportCertificate4
import ThetaSupportCertificate5
import ThetaSupportCertificate6
import ThetaTaxonRestriction
import ZeroTheta
import Lean.Util.CollectAxioms
open Lean Elab Command
run_cmd do
  let environment ← getEnv
  let names : Array String := #["AnchorReduction", "AnchorUnboundedSupport", "AnchorUnboundedTheorem", "BoundedThetaTheorem", "CanonicalTheta", "ThetaCertificate", "ThetaCertificate6", "ThetaDeletedHybrid", "ThetaFiniteEndpoint", "ThetaKernelSupport_0_0_0_3", "ThetaKernelSupport_0_0_0_4", "ThetaKernelSupport_0_0_0_5", "ThetaKernelSupport_0_0_0_6", "ThetaKernelSupport_0_0_1_2", "ThetaKernelSupport_0_0_1_3", "ThetaKernelSupport_0_0_1_4", "ThetaKernelSupport_0_0_1_5", "ThetaKernelSupport_0_0_2_1", "ThetaKernelSupport_0_0_2_2", "ThetaKernelSupport_0_0_2_3", "ThetaKernelSupport_0_0_2_4", "ThetaKernelSupport_0_0_3_0", "ThetaKernelSupport_0_0_3_1", "ThetaKernelSupport_0_0_3_2", "ThetaKernelSupport_0_0_3_3", "ThetaKernelSupport_0_0_4_0", "ThetaKernelSupport_0_0_4_1", "ThetaKernelSupport_0_0_4_2", "ThetaKernelSupport_0_0_5_0", "ThetaKernelSupport_0_0_5_1", "ThetaKernelSupport_0_0_6_0", "ThetaKernelSupport_0_1_0_2", "ThetaKernelSupport_0_1_0_3", "ThetaKernelSupport_0_1_0_4", "ThetaKernelSupport_0_1_0_5", "ThetaKernelSupport_0_1_1_1", "ThetaKernelSupport_0_1_1_2", "ThetaKernelSupport_0_1_1_3", "ThetaKernelSupport_0_1_1_4", "ThetaKernelSupport_0_1_2_0", "ThetaKernelSupport_0_1_2_1", "ThetaKernelSupport_0_1_2_2", "ThetaKernelSupport_0_1_2_3", "ThetaKernelSupport_0_1_3_0", "ThetaKernelSupport_0_1_3_1", "ThetaKernelSupport_0_1_3_2", "ThetaKernelSupport_0_1_4_0", "ThetaKernelSupport_0_1_4_1", "ThetaKernelSupport_0_1_5_0", "ThetaKernelSupport_0_2_0_1", "ThetaKernelSupport_0_2_0_2", "ThetaKernelSupport_0_2_0_3", "ThetaKernelSupport_0_2_0_4", "ThetaKernelSupport_0_2_1_0", "ThetaKernelSupport_0_2_1_1", "ThetaKernelSupport_0_2_1_2", "ThetaKernelSupport_0_2_1_3", "ThetaKernelSupport_0_2_2_0", "ThetaKernelSupport_0_2_2_1", "ThetaKernelSupport_0_2_2_2", "ThetaKernelSupport_0_2_3_0", "ThetaKernelSupport_0_2_3_1", "ThetaKernelSupport_0_2_4_0", "ThetaKernelSupport_0_3_0_0", "ThetaKernelSupport_0_3_0_1", "ThetaKernelSupport_0_3_0_2", "ThetaKernelSupport_0_3_0_3", "ThetaKernelSupport_0_3_1_0", "ThetaKernelSupport_0_3_1_1", "ThetaKernelSupport_0_3_1_2", "ThetaKernelSupport_0_3_2_0", "ThetaKernelSupport_0_3_2_1", "ThetaKernelSupport_0_3_3_0", "ThetaKernelSupport_0_4_0_0", "ThetaKernelSupport_0_4_0_1", "ThetaKernelSupport_0_4_0_2", "ThetaKernelSupport_0_4_1_0", "ThetaKernelSupport_0_4_1_1", "ThetaKernelSupport_0_4_2_0", "ThetaKernelSupport_0_5_0_0", "ThetaKernelSupport_0_5_0_1", "ThetaKernelSupport_0_5_1_0", "ThetaKernelSupport_0_6_0_0", "ThetaKernelSupport_1_0_0_2", "ThetaKernelSupport_1_0_0_3", "ThetaKernelSupport_1_0_0_4", "ThetaKernelSupport_1_0_0_5", "ThetaKernelSupport_1_0_1_1", "ThetaKernelSupport_1_0_1_2", "ThetaKernelSupport_1_0_1_3", "ThetaKernelSupport_1_0_1_4", "ThetaKernelSupport_1_0_2_0", "ThetaKernelSupport_1_0_2_1", "ThetaKernelSupport_1_0_2_2", "ThetaKernelSupport_1_0_2_3", "ThetaKernelSupport_1_0_3_0", "ThetaKernelSupport_1_0_3_1", "ThetaKernelSupport_1_0_3_2", "ThetaKernelSupport_1_0_4_0", "ThetaKernelSupport_1_0_4_1", "ThetaKernelSupport_1_0_5_0", "ThetaKernelSupport_1_1_0_1", "ThetaKernelSupport_1_1_0_2", "ThetaKernelSupport_1_1_0_3", "ThetaKernelSupport_1_1_0_4", "ThetaKernelSupport_1_1_1_0", "ThetaKernelSupport_1_1_1_1", "ThetaKernelSupport_1_1_1_2", "ThetaKernelSupport_1_1_1_3", "ThetaKernelSupport_1_1_2_0", "ThetaKernelSupport_1_1_2_1", "ThetaKernelSupport_1_1_2_2", "ThetaKernelSupport_1_1_3_0", "ThetaKernelSupport_1_1_3_1", "ThetaKernelSupport_1_1_4_0", "ThetaKernelSupport_1_2_0_0", "ThetaKernelSupport_1_2_0_1", "ThetaKernelSupport_1_2_0_2", "ThetaKernelSupport_1_2_0_3", "ThetaKernelSupport_1_2_1_0", "ThetaKernelSupport_1_2_1_1", "ThetaKernelSupport_1_2_1_2", "ThetaKernelSupport_1_2_2_0", "ThetaKernelSupport_1_2_2_1", "ThetaKernelSupport_1_2_3_0", "ThetaKernelSupport_1_3_0_0", "ThetaKernelSupport_1_3_0_1", "ThetaKernelSupport_1_3_0_2", "ThetaKernelSupport_1_3_1_0", "ThetaKernelSupport_1_3_1_1", "ThetaKernelSupport_1_3_2_0", "ThetaKernelSupport_1_4_0_0", "ThetaKernelSupport_1_4_0_1", "ThetaKernelSupport_1_4_1_0", "ThetaKernelSupport_1_5_0_0", "ThetaKernelSupport_2_0_0_1", "ThetaKernelSupport_2_0_0_2", "ThetaKernelSupport_2_0_0_3", "ThetaKernelSupport_2_0_0_4", "ThetaKernelSupport_2_0_1_0", "ThetaKernelSupport_2_0_1_1", "ThetaKernelSupport_2_0_1_2", "ThetaKernelSupport_2_0_1_3", "ThetaKernelSupport_2_0_2_0", "ThetaKernelSupport_2_0_2_1", "ThetaKernelSupport_2_0_2_2", "ThetaKernelSupport_2_0_3_0", "ThetaKernelSupport_2_0_3_1", "ThetaKernelSupport_2_0_4_0", "ThetaKernelSupport_2_1_0_0", "ThetaKernelSupport_2_1_0_1", "ThetaKernelSupport_2_1_0_2", "ThetaKernelSupport_2_1_0_3", "ThetaKernelSupport_2_1_1_0", "ThetaKernelSupport_2_1_1_1", "ThetaKernelSupport_2_1_1_2", "ThetaKernelSupport_2_1_2_0", "ThetaKernelSupport_2_1_2_1", "ThetaKernelSupport_2_1_3_0", "ThetaKernelSupport_2_2_0_0", "ThetaKernelSupport_2_2_0_1", "ThetaKernelSupport_2_2_0_2", "ThetaKernelSupport_2_2_1_0", "ThetaKernelSupport_2_2_1_1", "ThetaKernelSupport_2_2_2_0", "ThetaKernelSupport_2_3_0_0", "ThetaKernelSupport_2_3_0_1", "ThetaKernelSupport_2_3_1_0", "ThetaKernelSupport_2_4_0_0", "ThetaKernelSupport_3_0_0_0", "ThetaKernelSupport_3_0_0_1", "ThetaKernelSupport_3_0_0_2", "ThetaKernelSupport_3_0_0_3", "ThetaKernelSupport_3_0_1_0", "ThetaKernelSupport_3_0_1_1", "ThetaKernelSupport_3_0_1_2", "ThetaKernelSupport_3_0_2_0", "ThetaKernelSupport_3_0_2_1", "ThetaKernelSupport_3_0_3_0", "ThetaKernelSupport_3_1_0_0", "ThetaKernelSupport_3_1_0_1", "ThetaKernelSupport_3_1_0_2", "ThetaKernelSupport_3_1_1_0", "ThetaKernelSupport_3_1_1_1", "ThetaKernelSupport_3_1_2_0", "ThetaKernelSupport_3_2_0_0", "ThetaKernelSupport_3_2_0_1", "ThetaKernelSupport_3_2_1_0", "ThetaKernelSupport_3_3_0_0", "ThetaKernelSupport_4_0_0_0", "ThetaKernelSupport_4_0_0_1", "ThetaKernelSupport_4_0_0_2", "ThetaKernelSupport_4_0_1_0", "ThetaKernelSupport_4_0_1_1", "ThetaKernelSupport_4_0_2_0", "ThetaKernelSupport_4_1_0_0", "ThetaKernelSupport_4_1_0_1", "ThetaKernelSupport_4_1_1_0", "ThetaKernelSupport_4_2_0_0", "ThetaKernelSupport_5_0_0_0", "ThetaKernelSupport_5_0_0_1", "ThetaKernelSupport_5_0_1_0", "ThetaKernelSupport_5_1_0_0", "ThetaKernelSupport_6_0_0_0", "ThetaKernelTemplate_0_0_0_6", "ThetaKernelTemplate_0_0_1_5", "ThetaKernelTemplate_0_0_2_4", "ThetaKernelTemplate_0_0_3_3", "ThetaKernelTemplate_0_0_4_2", "ThetaKernelTemplate_0_0_5_1", "ThetaKernelTemplate_0_0_6_0", "ThetaKernelTemplate_0_1_0_5", "ThetaKernelTemplate_0_1_1_4", "ThetaKernelTemplate_0_1_2_3", "ThetaKernelTemplate_0_1_3_2", "ThetaKernelTemplate_0_1_4_1", "ThetaKernelTemplate_0_1_5_0", "ThetaKernelTemplate_0_2_0_4", "ThetaKernelTemplate_0_2_1_3", "ThetaKernelTemplate_0_2_2_2", "ThetaKernelTemplate_0_2_3_1", "ThetaKernelTemplate_0_2_4_0", "ThetaKernelTemplate_0_3_0_3", "ThetaKernelTemplate_0_3_1_2", "ThetaKernelTemplate_0_3_2_1", "ThetaKernelTemplate_0_3_3_0", "ThetaKernelTemplate_0_4_0_2", "ThetaKernelTemplate_0_4_1_1", "ThetaKernelTemplate_0_4_2_0", "ThetaKernelTemplate_0_5_0_1", "ThetaKernelTemplate_0_5_1_0", "ThetaKernelTemplate_0_6_0_0", "ThetaKernelTemplate_1_0_0_5", "ThetaKernelTemplate_1_0_1_4", "ThetaKernelTemplate_1_0_2_3", "ThetaKernelTemplate_1_0_3_2", "ThetaKernelTemplate_1_0_4_1", "ThetaKernelTemplate_1_0_5_0", "ThetaKernelTemplate_1_1_0_4", "ThetaKernelTemplate_1_1_1_3", "ThetaKernelTemplate_1_1_2_2", "ThetaKernelTemplate_1_1_3_1", "ThetaKernelTemplate_1_1_4_0", "ThetaKernelTemplate_1_2_0_3", "ThetaKernelTemplate_1_2_1_2", "ThetaKernelTemplate_1_2_2_1", "ThetaKernelTemplate_1_2_3_0", "ThetaKernelTemplate_1_3_0_2", "ThetaKernelTemplate_1_3_1_1", "ThetaKernelTemplate_1_3_2_0", "ThetaKernelTemplate_1_4_0_1", "ThetaKernelTemplate_1_4_1_0", "ThetaKernelTemplate_1_5_0_0", "ThetaKernelTemplate_2_0_0_4", "ThetaKernelTemplate_2_0_1_3", "ThetaKernelTemplate_2_0_2_2", "ThetaKernelTemplate_2_0_3_1", "ThetaKernelTemplate_2_0_4_0", "ThetaKernelTemplate_2_1_0_3", "ThetaKernelTemplate_2_1_1_2", "ThetaKernelTemplate_2_1_2_1", "ThetaKernelTemplate_2_1_3_0", "ThetaKernelTemplate_2_2_0_2", "ThetaKernelTemplate_2_2_1_1", "ThetaKernelTemplate_2_2_2_0", "ThetaKernelTemplate_2_3_0_1", "ThetaKernelTemplate_2_3_1_0", "ThetaKernelTemplate_2_4_0_0", "ThetaKernelTemplate_3_0_0_3", "ThetaKernelTemplate_3_0_1_2", "ThetaKernelTemplate_3_0_2_1", "ThetaKernelTemplate_3_0_3_0", "ThetaKernelTemplate_3_1_0_2", "ThetaKernelTemplate_3_1_1_1", "ThetaKernelTemplate_3_1_2_0", "ThetaKernelTemplate_3_2_0_1", "ThetaKernelTemplate_3_2_1_0", "ThetaKernelTemplate_3_3_0_0", "ThetaKernelTemplate_4_0_0_2", "ThetaKernelTemplate_4_0_1_1", "ThetaKernelTemplate_4_0_2_0", "ThetaKernelTemplate_4_1_0_1", "ThetaKernelTemplate_4_1_1_0", "ThetaKernelTemplate_4_2_0_0", "ThetaKernelTemplate_5_0_0_1", "ThetaKernelTemplate_5_0_1_0", "ThetaKernelTemplate_5_1_0_0", "ThetaKernelTemplate_6_0_0_0", "ThetaRepair", "ThetaSourceUnbounded", "ThetaSupportCertificate", "ThetaSupportCertificate3", "ThetaSupportCertificate4", "ThetaSupportCertificate5", "ThetaSupportCertificate6", "ThetaTaxonRestriction", "ZeroTheta"]
  let imported := environment.header.moduleNames.map Name.toString
  let indices := environment.header.moduleNames.map (fun n => names.contains n.toString)
  let mut declarations : Array Json := #[]
  let mut invalid : Array Json := #[]
  let mut ownedAxioms : Array String := #[]
  let mut theorems : Nat := 0
  for (name, information) in environment.constants do
    if let some index := environment.getModuleIdxFor? name then
      if indices[index.toNat]! then
        let axioms ← collectAxioms name
        let kind := match information with
          | .thmInfo _ => "theorem"
          | .axiomInfo _ => "axiom"
          | .defnInfo _ => "definition"
          | .opaqueInfo _ => "opaque"
          | .inductInfo _ => "inductive"
          | .ctorInfo _ => "constructor"
          | .recInfo _ => "recursor"
          | .quotInfo _ => "quotient"
        if kind == "theorem" then theorems := theorems + 1
        if kind == "axiom" then ownedAxioms := ownedAxioms.push name.toString
        let refs := match information.value? (allowOpaque := true) with
          | some expression => expression.getUsedConstants.map Name.toString
          | none => #[]
        let record := Json.mkObj [
          ("module", toJson imported[index.toNat]!), ("name", toJson name.toString),
          ("kind", toJson kind), ("axioms", toJson (axioms.map Name.toString)),
          ("type_references", toJson (information.type.getUsedConstants.map Name.toString)),
          ("body_references", toJson refs)]
        declarations := declarations.push record
        if axioms.any (fun ax => ! #[``propext, ``Classical.choice, ``Quot.sound].contains ax) then
          invalid := invalid.push record
  let missing := names.filter (fun n => ! imported.contains n)
  let result := Json.mkObj [
    ("selected_modules", toJson names), ("all_imported_module_names", toJson imported),
    ("declaration_count", toJson declarations.size),
    ("theorem_declaration_count", toJson theorems), ("owned_axioms", toJson ownedAxioms),
    ("nonstandard_axiom_rows", toJson invalid), ("missing_modules", toJson missing),
    ("declarations", toJson declarations)]
  liftIO <| IO.FS.writeFile "AUDIT-RESULT.json" result.pretty
  logInfo m!"Fresh closure: {declarations.size} declarations, {theorems} theorems, {ownedAxioms.size} owned axioms, {invalid.size} nonstandard rows, {missing.size} missing modules"
  unless ownedAxioms.isEmpty && invalid.isEmpty && missing.isEmpty do
    throwError "Fresh complete closure audit failed"
