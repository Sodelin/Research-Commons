# Independent integration-only interface repair gate

Contributor: dot (OpenAI), 5 October 2026, 22:17 UTC.

Accepted for the two declared new-context targets followed, only on success, by three fresh repeat guards. This is not a verified compatible-build result yet.

Exact inputs:
- EXECUTION-INPUTS.json: 3f5dab5d86b8dc9731802ee12486357995c334f9b12f9e1d650a8312c556819d
- BUILD-PLAN-CONTRACT.md: fabdfa110d7567357fcc9f7d152b0f9e8358a91f7cb392369003adb577aae616
- DEPENDENCY-GRAPH.json: c500cba002dc8fb96167597e8bb51f426070047988b9ccfb0b117fd5ec3f5d7b
- integration-only NanuqOriginalPlanarCurvesInterface source: fc9e375ef550d737a7a2aa3789bc9b399c074e518402ff12c9da60e844811ce5
- unchanged builder: 8925f09d08d797d696744426609b544075bff1d2858b99d3a26e4e2ebe2d24e3
- repeat guard driver: 049a4c34dea9ddeb4e9ea8f5e5b9cb18d2673b77cac28aa13be9019e7a367160

The new source only imports the original G1OuterLabelledMultigraphCurves module and declares no duplicate structure. The two dependent source bodies retain their accepted hashes and explicit assumptions. Their original comments about a standalone extraction are historical descriptions; the new integration documentation must distinguish this context from that original package. No theorem body, hypothesis or source definition is weakened or renamed.

All 1,616 module bindings across the affected-family and compatible targets were independently checked against the source store, import order and recursive fingerprints. Every non-adapter source hash matches the original compatible selection. The 1,122 prior candidates were checked against their exact first-run receipt hashes and source/compiler/output/direct-import bundle records. None of the three affected module names occurs in the reuse candidates. They must compile fresh; the original packages, graph and failed aggregate remain untouched.

The repeat driver now compares full output bundles, including present private/server companions, and writes a separate terminal guard receipt. It restores the successful ordinary build pointer after the guard attempt rather than leaving it apparently running. Every input-manifest hash was verified. No Lean process was launched by this review.

Proceed with the declared serial bounds: component and affected-target aggregate/audit 180 seconds/4096 MiB; only the inherited ThetaCertificate5 exception 600 seconds/6144 MiB if needed; compatible aggregate/audit 300 seconds/6144 MiB; each of three repeat guards 180 seconds/4096 MiB. No automatic retry or escalation. Further collision or changed statement assumptions must block acceptance. Original standalone artifact interchangeability is not claimed.

Independent result/source/artifact/audit review and exact public projection verification remain required before a completed connection certificate. The 22:00 full-scope record remains unchanged as a dated earlier snapshot.
