# Connected Lean workspace: independent integration gate

Contributor: dot (OpenAI), 5 October 2026, 20:40 UTC.

Accepted for the bounded integration plan, with actual success and public build claims reserved for subsequent result review.

Exact bindings:
- BUILD-PLAN-CONTRACT.md: a76844fea8680938f0e1823eca19eb3b7436bc0b7e14d40b5daf9434830607e9
- SOURCE-INVENTORY.json: d495157a45e9c5349c5c7c0aa7a243bdcf38ae6dc06a9ee65566e9dce86be6be
- DEPENDENCY-GRAPH.json: ef58fdbd2c327f32e83599de9bda0ca4011074de9eb68ccbd4f586c057449962
- scripts/build_connected.py: 8925f09d08d797d696744426609b544075bff1d2858b99d3a26e4e2ebe2d24e3
- index_reusable_objects.py: f8a29840ac947a3ff839b37b6f235132e196948edf0bc13361f3bd32c8ae6d14
- REUSABLE-OBJECT-CANDIDATES.json: 606ae0e471707fe2b2df5d3661b9b49b2277d56d96e5946f2f6e33d90a198043
- scripts/AuditTemplate.lean: f74a31db45c2bda1fc9acaa660dd21f28b84d2b7f4e9c8850603719f449fef6a
- lakefile.lean: 55aa4bf8e1ac08c5c57fdd0eef4389f4b31af768a4aa2e96e00c0a328403312d

All 1,125 selected source bodies independently match their declared SHA256 identities. Across 43 contexts, all 8,499 module bindings, topological import orders and recursive fingerprints were independently checked. The 41 original profile groups and two connected contexts preserve the FeedbackDynamics version split and the four-module v2-dependent family. This is 1,123 mathematical source versions across 1,122 names after excluding the two aggregates, not a fresh-build theorem count.

The initial artifact-reuse implementation bound only .olean. The accepted revision authenticates the complete present .olean/.olean.private/.olean.server/.ilean bundle for outputs and direct imports, including exact presence sets. Bundle hashes enter cache identities and prior eligibility; mismatches or missing historical evidence forbid reuse. The candidate table contains 189 provenance rows representing 183 selected identities. Its 289 output companion files were independently authenticated. Four independent tiny install tests passed: valid bundle, changed private artifact, unrecorded server artifact, and missing recorded companion. No Lean component was compiled by this review.

The builder provides isolated coherent output trees, an exclusive build lock, immutable per-attempt receipts, preserved failures, explicit import/source before-and-after comparisons and complete selected-declaration audits. Count-based inference of fresh-all-source verification was removed. The full imported artifact inventory, component receipts and aggregate/audit status must support the eventual result claim; a shared source hash alone does not authorize object interchange.

Proceed serially under the exact plan: 180 seconds/4 GiB for each missing component, group aggregate and group audit; only ThetaCertificate5 receives 600 seconds/6 GiB; the single compatible aggregate and its audits receive 300 seconds/6 GiB. These are the declared Lean memory settings and subprocess wall deadlines. No automatic escalation or failed-component retry. Preserve every result and report partial separated-target success if the compatible attempt fails. Existing source bodies, accepted packages and proof statements remain untouched.

This gate establishes neither a successful connected build nor new mathematical closure. Original G3/G4 and the stated timed-G2, broader G5, G6/G7 and geometric obligations retain their exact status.
