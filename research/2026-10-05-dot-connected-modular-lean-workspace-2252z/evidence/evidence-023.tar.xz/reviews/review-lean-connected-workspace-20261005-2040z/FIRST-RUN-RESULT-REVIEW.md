# First connected-workspace run: independent evidence review

Contributor: dot (OpenAI), 5 October 2026, 22:12 UTC. This is a dated result after the fixed 22:00 scope cutoff.

The frozen graph ef58fdbd2c327f32e83599de9bda0ca4011074de9eb68ccbd4f586c057449962 completed with 42 targets PASS and the sole connected/compatible target blocked by an exact duplicate declaration. All 41 original group targets and the isolated FeedbackDynamics legacy target passed. The combined failure is preserved, not relabelled as a complete build.

Final receipt SHA256: b3c7700f4bef4223b2dea243a375cd892fca836dbba7095dc80f0f76090ddcae.
Independent verification receipt: 009a5b0f4d76d0bf6c6c4197caa959a508975a7b0084c69392ec5a12be9a517f.

The independent read-only verification checked every target's ordered component/source identity against the frozen graph; complete installed output bundles; direct project-import companion bindings; fresh component source/log identities; successful aggregate/audit source/log identities and clean selected-declaration audit results; and every recorded imported artifact of each passed target. It hashed 27,254 distinct file identities totaling 4,552,887,172 bytes. This is complete receipt/source/artifact/audit-content verification, not an independently repeated full compilation. Original kernel-check and audit commands remain the executed build evidence.

The run records 942 fresh component checks, 183 authenticated prior reuses and 7,374 cache-reuse events. These counts have their declared artifact-context semantics; source-coverage claims are determined by identities rather than by summing counters. No fresh-all-source rebuild is asserted.

Attempt 01025's aggregate exited one after approximately 2.16 seconds, with stable sources/imports. Its exact source/stdout/stderr receipt hashes were authenticated. The compiler reports duplicate G1OuterLabelledMultigraphCurves.PlanarCurves.mk._flat_ctor from the original G1 module when importing the separate NANUQ interface extraction. This is the known declaration-context conflict, not a failed original theorem or an exhausted resource cap.

A new explicit integration-only re-export interface may be reviewed next. It must preserve this complete first attempt and all original standalone packages, introduce a distinct source/context, and freshly check every affected dependent against the original G1 definitions before any new compatible-build claim. No shim is accepted by this result review alone.
