from pathlib import Path
import os,signal,subprocess,time,shutil,json,resource
P=Path(__file__).resolve().parent;CAP=256*1024**2;FLOOR=int(2.10*1024**3)
def usage():
 total=0
 for root,dirs,files in os.walk(P,followlinks=False):
  total+=os.lstat(root).st_blocks*512
  for n in files:
   q=Path(root)/n
   try:
    if not q.is_symlink():total+=q.stat().st_blocks*512
   except FileNotFoundError:pass
 return total
assert shutil.disk_usage(P).free>=FLOOR and usage()<CAP
resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2))
start=time.monotonic();reason=None;peak=usage();minimum=shutil.disk_usage(P).free
with (P/'SOURCE-BEZOUT-GENERATION-STDOUT.log').open('wb') as out,(P/'SOURCE-BEZOUT-GENERATION-STDERR.log').open('wb') as err:
 child=subprocess.Popen(['python3',str(P/'generate_source_bezout.py')],cwd=P,stdout=out,stderr=err,start_new_session=True,env=dict(os.environ,TMPDIR=str(P/'scratch')))
 while child.poll() is None:
  size=usage();free=shutil.disk_usage(P).free;peak=max(peak,size);minimum=min(minimum,free)
  if size>=CAP:reason='TOTAL_ALLOCATION_LIMIT'
  elif free<FLOOR:reason='FREE_FLOOR'
  elif time.monotonic()-start>185:reason='WALL_LIMIT'
  if reason:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   break
  time.sleep(.05)
 code=child.wait()
r={'status':'PASS' if code==0 and reason is None else 'FAILED_OR_RESOURCE','exit_code':code,'limit_event':reason,'elapsed_seconds':time.monotonic()-start,'peak_observed_allocated_bytes':max(peak,usage()),'free_floor_bytes':FLOOR,'minimum_free_bytes':minimum,'allocation_limit_bytes':CAP,'per_file_hard_limit_bytes':32*1024**2,'cpu_limit_seconds':180,'memory_limit_mib':4096,'no_evidence_deleted':True}
(P/'SOURCE-BEZOUT-GENERATION-RECEIPT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(0 if r['status']=='PASS' else 1)
