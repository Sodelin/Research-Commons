from pathlib import Path
import hashlib,json,os,signal,subprocess,time,shutil
P=Path(__file__).resolve().parent;CAP=256*1024**2;FLOOR=int(2.10*1024**3)
def usage():
 total=0
 for root,dirs,files in os.walk(P,followlinks=False):
  total+=os.lstat(root).st_blocks*512
  for name in files:
   p=Path(root)/name
   try:
    if not p.is_symlink():total+=p.stat().st_blocks*512
   except FileNotFoundError:pass
 return total
env=dict(os.environ,CONNECTED_LEAN_BIN='<LOCAL_PATH_1588406f0000>',CONNECTED_MATHLIB='<LOCAL_PATH_120f8d75dc56>',LEAN_NUM_THREADS='1',TMPDIR=str(P/'scratch'))
(P/'scratch').mkdir(exist_ok=True);start=time.monotonic();reason=None;peak=usage();minimum_free=shutil.disk_usage(P).free
with (P/'SUPERVISOR-STDOUT.log').open('wb') as out,(P/'SUPERVISOR-STDERR.log').open('wb') as err:
 child=subprocess.Popen(['python3',str(P/'run_bounded_profile.py')],cwd=P,env=env,stdout=out,stderr=err,start_new_session=True)
 while child.poll() is None:
  size=usage();free=shutil.disk_usage(P).free;peak=max(peak,size);minimum_free=min(minimum_free,free)
  if size>=CAP:reason='TOTAL_RUN_ALLOCATION_LIMIT'
  elif free<FLOOR:reason='TMPFS_FREE_SPACE_FLOOR'
  elif time.monotonic()-start>780:reason='SUPERVISOR_WALL_LIMIT'
  if reason:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   break
  time.sleep(.05)
 code=child.wait()
peak=max(peak,usage());receipt={'status':'TERMINAL_EXIT_ZERO' if code==0 and reason is None and peak<CAP else 'FAILED_OR_RESOURCE','exit_code':code,'limit_event':reason,'elapsed_seconds':time.monotonic()-start,'peak_observed_allocated_bytes':peak,'allocation_limit_bytes':CAP,'minimum_observed_free_bytes':minimum_free,'free_floor_bytes':FLOOR,'per_file_hard_limit_bytes':32*1024**2,'allocation_poll_seconds':.05,'file_limit_mechanism':'RLIMIT_FSIZE hard limit','total_limit_mechanism':'allocated-block supervisor with termination; observed peaks reported, not a filesystem quota','no_evidence_deleted':True}
(P/'SUPERVISOR-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt['status']=='TERMINAL_EXIT_ZERO' else 1)
