from pathlib import Path
import json,hashlib,time,fcntl,resource
import sympy as S
from sympy.polys.matrices import DomainMatrix
P=Path(__file__).resolve().parent;src=Path('<LOCAL_PATH_fbf8b114bf92>')
lock=open('<LOCAL_PATH_d9255267ef3a>','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
resource.setrlimit(resource.RLIMIT_CPU,(180,180));resource.setrlimit(resource.RLIMIT_AS,(4096*1024**2,4096*1024**2));resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2))
r,p=S.symbols('r p');t0=time.monotonic();data=json.loads((src/'symbolic-normal-pilot.json').read_text());B=[S.Poly.from_list(list(map(int,a)),r,domain=S.ZZ) for a in data['B_coefficients_descending']];domain=S.ZZ.poly_ring(r)
asc=lambda f:list(map(int,reversed(S.Poly(f,r,domain=S.ZZ).all_coeffs())))
for z in [3,5]:
 ff=[S.Poly(1-p+p*z**l,p,domain=domain) for l in data['lambda']];F=S.Poly(0,p,domain=domain);Q0=F
 for i,l in enumerate(data['lambda']):
  prod=S.Poly(1,p,domain=domain)
  for j in range(6):
   if j!=i:prod*=ff[j]
  F+=prod.mul_ground(B[i].as_expr()*(1-z**l));Q0+=prod.mul_ground(B[i].as_expr()*l*z**(l-1))
 Q=Q0.exquo(S.Poly(1-p,p,domain=domain));assert F.degree()==5 and Q.degree()==4
 columns=[F.shift(0)] if False else []
 for j in range(4):columns.append(F*S.Poly(p**j,p,domain=domain))
 for j in range(5):columns.append(Q*S.Poly(p**j,p,domain=domain))
 raw=[[domain.from_sympy(col.nth(i)) for col in columns] for i in range(9)]
 mat=DomainMatrix(raw,(9,9),domain);rhs=DomainMatrix([[domain.one if i==0 else domain.zero] for i in range(9)],(9,1),domain)
 print(json.dumps({'stage':'matrix_built','slice':z,'seconds':time.monotonic()-t0}),flush=True)
 sol,den=mat.solve_den(rhs,method='charpoly');print(json.dumps({'stage':'charpoly_solved','slice':z,'seconds':time.monotonic()-t0}),flush=True);assert mat*sol==rhs.scalarmul(den)
 denpoly=S.Poly(domain.to_sympy(den),r,domain=S.ZZ);vals=[S.Poly(domain.to_sympy(row[0]),r,domain=S.ZZ) for row in sol.to_list()]
 # Normalize a common integer content only; do not assume polynomial cancellation.
 g=abs(S.polys.polytools.terms_gcd(denpoly.as_expr()).as_coeff_Mul()[0]) if False else 0
 from math import gcd
 for a in [denpoly]+vals:
  for v in a.all_coeffs():g=gcd(g,int(v))
 assert g>0
 denpoly=denpoly.exquo_ground(g);vals=[v.exquo_ground(g) for v in vals]
 u=sum(vals[j].as_expr()*p**j for j in range(4));v=sum(vals[4+j].as_expr()*p**j for j in range(5));assert S.Poly(u*F.as_expr()+v*Q.as_expr()-denpoly.as_expr(),p,r).is_zero
 rec=json.loads((src/f'slice-{z}-resultant.json').read_text());E=S.Poly.from_list(list(map(int,rec['primitive_coefficients_descending'])),r,domain=S.QQ)
 quotient=E.exquo(denpoly.set_domain(S.QQ));scale,quotient_int=quotient.clear_denoms(convert=True)
 assert S.Poly(scale,r,domain=S.ZZ)*E.set_domain(S.ZZ)==denpoly*quotient_int
 out={'status':'PASS_SOURCE_POLYNOMIAL_BEZOUT_AND_EXPORTED_POLYNOMIAL_DIVISIBILITY','slice_q':z,'lambda':data['lambda'],'P_p_coefficients_r_ascending':[asc(F.nth(i)) for i in range(6)],'Q_p_coefficients_r_ascending':[asc(Q.nth(i)) for i in range(5)],'U_p_coefficients_r_ascending':[asc(v.as_expr()) for v in vals[:4]],'V_p_coefficients_r_ascending':[asc(v.as_expr()) for v in vals[4:]],'D_r_coefficients_ascending':asc(denpoly.as_expr()),'W_r_coefficients_ascending':asc(quotient_int.as_expr()),'nonzero_integer_K':int(scale),'identity':'U*P + V*Q = D; D*W = K*primitive_E; Q0=(1-p)*Q','degrees':{'D_r':int(denpoly.degree()),'W_r':int(quotient_int.degree()),'U_r_max':max(int(v.degree()) for v in vals[:4]),'V_r_max':max(int(v.degree()) for v in vals[4:])},'sympy':S.__version__,'seconds_from_start':time.monotonic()-t0,'scope':'Exact symbolic candidate certificate. Not a Lean proof. Actual source B/array binding and all polynomial identities require independent and kernel verification.'}
 f=P/f'certificates/SOURCE-BEZOUT-{z}.json';f.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'slice':z,'degrees':out['degrees'],'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'seconds':out['seconds_from_start']}),flush=True)
