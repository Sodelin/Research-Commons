from pathlib import Path
import hashlib,json,os,resource,shutil,sys
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'scripts/build_connected.py')=='f74f8e24dd6a61f627c42e4106de442f1ba0adecaf06442b6a0a4e70cbe681be'
assert sha(P/'scripts/AuditTemplate.lean')=='f74a31db45c2bda1fc9acaa660dd21f28b84d2b7f4e9c8850603719f449fef6a'
assert sha(P/'DEPENDENCY-GRAPH.json')=='638c239709842efba1af5884cc6e9f2d0e390975d4cfee35cff13271a744b493'
assert (P/'.build/lock').resolve()==Path('<LOCAL_PATH_d9255267ef3a>')
MIN_FREE=int(2.10*1024**3);CAP=1536*1024**2;FILE_CAP=32*1024**2
resource.setrlimit(resource.RLIMIT_FSIZE,(FILE_CAP,FILE_CAP))
def allocation():
 total=0
 for root,dirs,files in os.walk(P,followlinks=False):
  total+=os.lstat(root).st_blocks*512
  for name in files:
   p=Path(root)/name
   if not p.is_symlink():total+=p.stat().st_blocks*512
 return total
def guard():
 free=shutil.disk_usage(P).free;used=allocation()
 if free<MIN_FREE:raise RuntimeError('DISK_FLOOR_BOUNDARY_PAUSE '+str(free))
 if used>=CAP:raise RuntimeError('TOTAL_RUN_ALLOCATION_BOUNDARY_PAUSE '+str(used))
guard();sys.path.insert(0,str(P/'scripts'));import build_connected as bc
b=bc.Builder();orig_comp=b.component;orig_invoke=b.invoke
bc.save(b.run/'BOUNDED-PROFILE-POLICY.json',{'wrapper_sha256':sha(Path(__file__)),'builder_sha256':sha(P/'scripts/build_connected.py'),'graph_sha256':sha(P/'DEPENDENCY-GRAPH.json'),'floor_bytes':MIN_FREE,'run_allocation_limit_bytes':CAP,'per_file_limit_bytes':FILE_CAP,'allocation_monitor':'external supervisor measures allocated blocks throughout; any limit event is FAILED_OR_RESOURCE, preserving partial evidence','fresh_cache_required':True,'only_target':'candidate/g3-actual-fixed-residue-critical-finiteness','original_package_profiles_unchanged':True})
def component(*a,**kw):guard();return orig_comp(*a,**kw)
def invoke(name,source,obj,imports,context,seconds,memory,kind):
 guard();assert seconds==180 and memory==4096
 return orig_invoke(name,source,obj,imports,context,seconds,memory,kind)
b.component=component;b.invoke=invoke
print('ACTUAL_RUN',b.run,flush=True)
raise SystemExit(b.run_targets(['candidate/g3-actual-fixed-residue-critical-finiteness']))
